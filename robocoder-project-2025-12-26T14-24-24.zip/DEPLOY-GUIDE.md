# 🚀 Guia de Deploy - Beacon Solutions Hub

## Seu site está pronto para deploy!

**Site atual funcionando:** https://sb-4x18js9w36vi.vercel.run

---

## 📋 **ARQUIVOS DO SEU SITE:**

### **Estrutura Completa:**
```
beacon-solutions-hub/
├── src/
│   ├── app/
│   │   ├── layout.tsx (Layout principal)
│   │   ├── page.tsx (Homepage)
│   │   ├── services/
│   │   │   ├── page.tsx (Todos os serviços)
│   │   │   ├── pintura/page.tsx
│   │   │   ├── pressure-washing/page.tsx
│   │   │   ├── vidros/page.tsx
│   │   │   └── paineis-solares/page.tsx
│   │   ├── como-funciona/page.tsx
│   │   ├── sobre/page.tsx
│   │   ├── logo-options/page.tsx
│   │   └── admin/page.tsx
│   ├── components/
│   │   ├── Navigation.tsx
│   │   ├── Footer.tsx
│   │   └── LogoShowcase.tsx
│   └── lib/utils.ts
├── package.json
├── next.config.ts
├── tailwind.config.ts
└── tsconfig.json
```

---

## 🌐 **OPÇÃO 1: VERCEL (RECOMENDADA)**

### **Por que Vercel?**
- ✅ **Gratuito** para sites como o seu
- ✅ **Deploy automático** a cada mudança
- ✅ **SSL certificado** grátis
- ✅ **CDN global** (site rápido no mundo todo)
- ✅ **Domínio personalizado** fácil de configurar

### **Passos para Deploy:**

#### **1. Criar Conta Vercel:**
- Acesse: [vercel.com](https://vercel.com)
- Clique "Sign Up" → Use GitHub, Google ou email

#### **2. Fazer Upload do Código:**
**Opção A - GitHub (Recomendada):**
- Crie repositório no GitHub
- Faça upload de todos os arquivos
- Conecte Vercel ao GitHub

**Opção B - Upload Direto:**
- Use Vercel CLI: `npm i -g vercel`
- Na pasta do projeto: `vercel`

#### **3. Configurar Domínio:**
- No painel Vercel → Seu projeto → Settings → Domains
- Adicione seu domínio
- Configure DNS conforme instruções

---

## 🌐 **OPÇÃO 2: NETLIFY**

### **Passos:**
1. **Conta:** [netlify.com](https://netlify.com)
2. **Deploy:** Arraste pasta do projeto ou conecte GitHub
3. **Domínio:** Settings → Domain management

---

## 🌐 **OPÇÃO 3: HOSTINGER/CPANEL**

### **Para hospedagem tradicional:**
1. **Build estático:** `npm run build && npm run export`
2. **Upload:** Pasta `out/` para public_html
3. **Domínio:** Configurar DNS

---

## ⚙️ **CONFIGURAÇÕES IMPORTANTES:**

### **Variáveis de Ambiente (.env.local):**
```
NEXT_PUBLIC_WHATSAPP_NUMBER=14071234567
NEXT_PUBLIC_PHONE_NUMBER=4071234567
NEXT_PUBLIC_EMAIL=contato@seudominio.com
NEXT_PUBLIC_SITE_URL=https://seudominio.com
```

### **Domínio Personalizado:**
- Atualize links WhatsApp se necessário
- Configure SSL (automático na Vercel/Netlify)
- Teste todas as funcionalidades

---

## 📞 **CONTATOS PARA ATUALIZAR:**

Quando tiver seu domínio, atualize:
- **WhatsApp:** Substitua `14071234567` pelo seu número
- **Telefone:** Substitua `(407) 123-4567` pelo seu número
- **Email:** Substitua `contato@beaconsolutionshub.com` pelo seu email

---

## 🎯 **PRÓXIMOS PASSOS:**

1. **Escolha a plataforma** (Vercel recomendada)
2. **Me informe seu domínio** para ajudar na configuração
3. **Faça o deploy** seguindo o guia
4. **Teste todas as funcionalidades**
5. **Personalize contatos** com seus dados reais

---

## 🆘 **PRECISA DE AJUDA?**

Me informe:
- Qual domínio você comprou?
- Qual plataforma prefere usar?
- Tem experiência com GitHub?

Posso te ajudar com cada passo do processo!
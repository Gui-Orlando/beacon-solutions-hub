import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Beacon Solutions Hub - Serviços para sua casa em um só lugar",
  description: "Profissionais verificados para pintura, limpeza, pressure washing e mais. Atendemos Orlando e região. Orçamento rápido e agendamento fácil.",
  keywords: "serviços residenciais, pintura, limpeza, pressure washing, Orlando, Florida",
  openGraph: {
    title: "Beacon Solutions Hub - Serviços Residenciais Orlando",
    description: "Profissionais verificados para sua casa. Orçamento rápido e agendamento fácil.",
    type: "website",
    locale: "pt_BR",
    alternateLocale: ["en_US", "es_ES"],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pt-BR">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#1e3a8a" />
      </head>
      <body className={`${inter.className} antialiased`}>
        <div className="min-h-screen flex flex-col">
          <Navigation />
          <main className="flex-1">
            {children}
          </main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
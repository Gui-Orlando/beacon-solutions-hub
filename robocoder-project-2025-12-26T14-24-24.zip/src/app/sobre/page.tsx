"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Users, Award, Shield, Heart, Target, Eye, MessageCircle, Phone } from "lucide-react";

export default function SobrePage() {
  const stats = [
    { number: "500+", label: "Clientes Satisfeitos", icon: <Users className="h-8 w-8 text-blue-600" /> },
    { number: "14", label: "Serviços Especializados", icon: <Award className="h-8 w-8 text-blue-600" /> },
    { number: "4.9", label: "Avaliação Média", icon: <CheckCircle className="h-8 w-8 text-blue-600" /> },
    { number: "2h", label: "Tempo de Resposta", icon: <Shield className="h-8 w-8 text-blue-600" /> }
  ];

  const values = [
    {
      icon: <Shield className="h-12 w-12 text-blue-600" />,
      title: "Confiança",
      description: "Construímos relacionamentos duradouros baseados na transparência, honestidade e cumprimento de promessas."
    },
    {
      icon: <Award className="h-12 w-12 text-blue-600" />,
      title: "Excelência",
      description: "Buscamos sempre a perfeição em cada serviço, utilizando os melhores materiais e técnicas do mercado."
    },
    {
      icon: <Heart className="h-12 w-12 text-blue-600" />,
      title: "Cuidado",
      description: "Tratamos sua casa como se fosse nossa, com respeito, atenção aos detalhes e cuidado com seus pertences."
    },
    {
      icon: <Users className="h-12 w-12 text-blue-600" />,
      title: "Parceria",
      description: "Mais que prestadores de serviço, somos parceiros na manutenção e valorização do seu lar."
    }
  ];

  const team = [
    {
      name: "Carlos Silva",
      role: "Fundador & CEO",
      experience: "15 anos em serviços residenciais",
      image: "https://placehold.co/300x300?text=Carlos+Silva+CEO+Professional+Portrait",
      description: "Especialista em gestão de serviços residenciais com foco em qualidade e satisfação do cliente."
    },
    {
      name: "Maria Rodriguez",
      role: "Gerente de Operações",
      experience: "12 anos em gestão de equipes",
      image: "https://placehold.co/300x300?text=Maria+Rodriguez+Operations+Manager+Portrait",
      description: "Responsável por garantir que todos os serviços sejam executados com excelência e pontualidade."
    },
    {
      name: "João Santos",
      role: "Coordenador de Qualidade",
      experience: "10 anos em controle de qualidade",
      image: "https://placehold.co/300x300?text=João+Santos+Quality+Coordinator+Portrait",
      description: "Especialista em treinamento de equipes e padronização de processos de qualidade."
    }
  ];

  const certifications = [
    "Licença comercial válida no estado da Flórida",
    "Seguro de responsabilidade civil",
    "Certificação em segurança do trabalho",
    "Treinamento em atendimento ao cliente",
    "Verificação de antecedentes criminais",
    "Certificação em manuseio de materiais químicos"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Sobre a Beacon Solutions Hub
              </h1>
              <p className="text-xl text-blue-100 mb-6">
                Somos uma empresa especializada em conectar você aos melhores 
                profissionais de serviços residenciais em Orlando e região.
              </p>
              <p className="text-lg text-blue-200 mb-8">
                Nossa missão é simplificar sua vida, oferecendo uma plataforma 
                única onde você encontra todos os serviços que sua casa precisa, 
                com qualidade garantida e suporte centralizado.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                  Nossos Serviços
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                  Entre em Contato
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://placehold.co/600x500?text=Beacon+Solutions+Hub+Team+Professional+Home+Services" 
                alt="Equipe Beacon Solutions Hub" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-6 rounded-lg shadow-lg">
                <div className="text-3xl font-bold text-blue-600">500+</div>
                <div className="text-sm text-gray-600">Clientes Satisfeitos</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="pt-6">
                  <div className="flex justify-center mb-4">
                    {stat.icon}
                  </div>
                  <div className="text-4xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <Target className="h-8 w-8 text-blue-600" />
                  <CardTitle className="text-2xl">Nossa Missão</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-gray-600 mb-4">
                  Conectar proprietários de residências aos melhores profissionais 
                  de serviços domésticos, garantindo qualidade, confiabilidade e 
                  conveniência em cada interação.
                </p>
                <p className="text-gray-600">
                  Acreditamos que cuidar da sua casa não deveria ser complicado. 
                  Por isso, criamos uma plataforma que centraliza todos os serviços 
                  que você precisa, com profissionais verificados e suporte dedicado.
                </p>
              </CardContent>
            </Card>

            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center gap-3 mb-4">
                  <Eye className="h-8 w-8 text-blue-600" />
                  <CardTitle className="text-2xl">Nossa Visão</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-gray-600 mb-4">
                  Ser a principal referência em serviços residenciais na região 
                  de Orlando, reconhecida pela excelência, inovação e satisfação 
                  total dos clientes.
                </p>
                <p className="text-gray-600">
                  Queremos transformar a experiência de manutenção residencial, 
                  tornando-a simples, confiável e acessível para todas as famílias 
                  da nossa comunidade.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nossos Valores
            </h2>
            <p className="text-xl text-gray-600">
              Os princípios que guiam cada decisão e ação da nossa empresa
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center h-full">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {value.icon}
                  </div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nossa Equipe
            </h2>
            <p className="text-xl text-gray-600">
              Profissionais dedicados ao seu sucesso e satisfação
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                  />
                  <CardTitle className="text-xl">{member.name}</CardTitle>
                  <CardDescription className="text-blue-600 font-medium">
                    {member.role}
                  </CardDescription>
                  <Badge variant="outline" className="mx-auto">
                    {member.experience}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{member.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Certificações e Licenças
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Operamos com total transparência e conformidade com todas as 
                regulamentações locais e estaduais.
              </p>
              <div className="space-y-3">
                {certifications.map((cert, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    <span className="text-gray-700">{cert}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <img 
                src="https://placehold.co/600x500?text=Professional+Certifications+Licenses+Quality+Standards"
                alt="Certificações e licenças"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Community Commitment */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Compromisso com a Comunidade
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Acreditamos em retribuir à comunidade que nos acolheu. Participamos 
              ativamente de iniciativas locais e apoiamos organizações beneficentes 
              em Orlando e região.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="pt-6 text-center">
                  <Heart className="h-12 w-12 text-red-500 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Ações Sociais</h3>
                  <p className="text-sm text-gray-600">
                    Serviços gratuitos para famílias em situação de vulnerabilidade
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <Users className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Geração de Empregos</h3>
                  <p className="text-sm text-gray-600">
                    Oportunidades para profissionais locais crescerem conosco
                  </p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="pt-6 text-center">
                  <Award className="h-12 w-12 text-blue-500 mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Sustentabilidade</h3>
                  <p className="text-sm text-gray-600">
                    Práticas eco-friendly e materiais sustentáveis
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              Faça Parte da Nossa História
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Junte-se aos mais de 500 clientes satisfeitos que confiam na 
              Beacon Solutions Hub para cuidar de suas casas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                Solicitar Orçamento
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                <Phone className="mr-2 h-5 w-5" />
                (407) 123-4567
              </Button>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                <MessageCircle className="mr-2 h-5 w-5" />
                WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
import { LogoShowcase } from "@/components/LogoShowcase";

export default function LogoOptionsPage() {
  return <LogoShowcase />;
}
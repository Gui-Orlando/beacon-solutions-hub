"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export default function AdminPage() {
  const [selectedService, setSelectedService] = useState("pintura");

  const serviceImages = {
    "pintura": {
      current: "https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400&h=300&fit=crop&crop=center",
      file: "src/app/page.tsx e src/app/services/page.tsx",
      line: "Linha ~95 e ~25"
    },
    "pressure-washing": {
      current: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop&crop=center",
      file: "src/app/page.tsx e src/app/services/page.tsx",
      line: "Linha ~101 e ~35"
    },
    "estofados": {
      current: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop&crop=center",
      file: "src/app/page.tsx e src/app/services/page.tsx",
      line: "Linha ~107 e ~45"
    },
    "limpeza-residencial": {
      current: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=400&h=300&fit=crop&crop=center",
      file: "src/app/page.tsx e src/app/services/page.tsx",
      line: "Linha ~113 e ~55"
    },
    "piscina": {
      current: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&h=300&fit=crop&crop=center",
      file: "src/app/page.tsx e src/app/services/page.tsx",
      line: "Linha ~125 e ~75"
    },
    "junk-removal": {
      current: "https://images.unsplash.com/photo-1566228015668-4c45dbc4e2f5?w=400&h=300&fit=crop&crop=center",
      file: "src/app/services/page.tsx",
      line: "Linha ~165"
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Painel de Administração - Beacon Solutions Hub
          </h1>
          <p className="text-xl text-gray-600">
            Como trocar fotos dos serviços e personalizar o site
          </p>
        </div>

        {/* Image Management Guide */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-blue-900">
                📸 Como Trocar Fotos dos Serviços
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="font-semibold text-blue-900 mb-2">Método 1: Unsplash (Recomendado)</h3>
                <ol className="text-sm space-y-2 text-gray-700">
                  <li>1. Acesse <a href="https://unsplash.com" target="_blank" className="text-blue-600 underline">unsplash.com</a></li>
                  <li>2. Pesquise pela foto desejada (ex: "pressure washing")</li>
                  <li>3. Clique na foto → Copie o link</li>
                  <li>4. Substitua no código: <code className="bg-gray-200 px-1 rounded">image: "NOVO_LINK_AQUI"</code></li>
                </ol>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="font-semibold text-green-900 mb-2">Método 2: Upload Próprio</h3>
                <ol className="text-sm space-y-2 text-gray-700">
                  <li>1. Coloque sua foto na pasta <code className="bg-gray-200 px-1 rounded">public/images/</code></li>
                  <li>2. Use: <code className="bg-gray-200 px-1 rounded">image: "/images/sua-foto.jpg"</code></li>
                  <li>3. Tamanho recomendado: 400x300px</li>
                </ol>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-blue-900">
                🎨 Localização das Imagens no Código
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {Object.entries(serviceImages).map(([key, info]) => (
                  <div key={key} className="border-l-4 border-blue-500 pl-4">
                    <div className="font-medium text-gray-900 capitalize">
                      {key.replace('-', ' ')}
                    </div>
                    <div className="text-sm text-gray-600">
                      Arquivo: <code className="bg-gray-100 px-1 rounded">{info.file}</code>
                    </div>
                    <div className="text-sm text-gray-600">
                      {info.line}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Logo Management */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900">
              🏷️ Como Trocar o Logo
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3">Locais do Logo no Site:</h3>
                <ul className="space-y-2 text-sm">
                  <li>• <strong>Navigation:</strong> <code className="bg-gray-100 px-1 rounded">src/components/Navigation.tsx</code> (linha ~35)</li>
                  <li>• <strong>Homepage:</strong> <code className="bg-gray-100 px-1 rounded">src/app/page.tsx</code> (linha ~180)</li>
                  <li>• <strong>Footer:</strong> <code className="bg-gray-100 px-1 rounded">src/components/Footer.tsx</code> (linha ~25)</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-3">Como Aplicar Novo Logo:</h3>
                <ol className="space-y-2 text-sm">
                  <li>1. Escolha uma opção em <a href="/logo-options" className="text-blue-600 underline">/logo-options</a></li>
                  <li>2. Substitua o código do logo nos 3 arquivos</li>
                  <li>3. Ou use sua própria imagem em <code className="bg-gray-100 px-1 rounded">public/logo.png</code></li>
                  <li>4. Rebuild o site: <code className="bg-gray-100 px-1 rounded">pnpm run build</code></li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-blue-900">
              ⚡ Ações Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <Button 
                className="h-20 flex flex-col"
                onClick={() => window.open('/logo-options', '_blank')}
              >
                <span className="text-lg mb-1">🎨</span>
                <span>Escolher Logo</span>
              </Button>
              <Button 
                variant="outline"
                className="h-20 flex flex-col"
                onClick={() => window.open('/services', '_blank')}
              >
                <span className="text-lg mb-1">🛠️</span>
                <span>Ver Serviços</span>
              </Button>
              <Button 
                variant="outline"
                className="h-20 flex flex-col"
                onClick={() => window.open('/', '_blank')}
              >
                <span className="text-lg mb-1">🏠</span>
                <span>Homepage</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Info */}
        <div className="mt-12 bg-blue-900 text-white rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Informações de Contato Atuais</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <div className="text-lg font-semibold">Telefone</div>
              <div>(407) 123-4567</div>
              <div className="text-sm text-blue-200">Para trocar: edite Navigation.tsx</div>
            </div>
            <div>
              <div className="text-lg font-semibold">WhatsApp</div>
              <div>+1 (407) 123-4567</div>
              <div className="text-sm text-blue-200">Para trocar: substitua "14071234567" no código</div>
            </div>
            <div>
              <div className="text-lg font-semibold">E-mail</div>
              <div>contato@beaconsolutionshub.com</div>
              <div className="text-sm text-blue-200">Para trocar: edite Footer.tsx</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone, MessageCircle, Star, CheckCircle, Clock, Shield, Users, Award } from "lucide-react";

export default function HomePage() {
  const [language, setLanguage] = useState("pt");

  const content = {
    pt: {
      hero: {
        title: "Serviços para sua casa em um só lugar",
        subtitle: "Agende em minutos. Profissionais verificados. Atendimento rápido e de confiança.",
        cta1: "Pedir Orçamento",
        cta2: "Agendar Agora",
        cta3: "Falar no WhatsApp"
      },
      services: {
        title: "Serviços Mais Pedidos",
        subtitle: "Escolha o serviço que você precisa"
      },
      whyChoose: {
        title: "Por que escolher a Beacon Solutions Hub?",
        subtitle: "Sua tranquilidade é nossa prioridade"
      },
      testimonials: {
        title: "O que nossos clientes dizem",
        subtitle: "Mais de 500 clientes satisfeitos em Orlando"
      },
      finalCta: {
        title: "Pronto para começar?",
        subtitle: "Receba seu orçamento em até 2 horas"
      }
    },
    en: {
      hero: {
        title: "Home services in one place",
        subtitle: "Schedule in minutes. Verified professionals. Fast and reliable service.",
        cta1: "Get Quote",
        cta2: "Schedule Now",
        cta3: "WhatsApp Us"
      },
      services: {
        title: "Most Requested Services",
        subtitle: "Choose the service you need"
      },
      whyChoose: {
        title: "Why choose Beacon Solutions Hub?",
        subtitle: "Your peace of mind is our priority"
      },
      testimonials: {
        title: "What our customers say",
        subtitle: "Over 500 satisfied customers in Orlando"
      },
      finalCta: {
        title: "Ready to get started?",
        subtitle: "Get your quote within 2 hours"
      }
    },
    es: {
      hero: {
        title: "Servicios para tu hogar en un solo lugar",
        subtitle: "Agenda en minutos. Profesionales verificados. Servicio rápido y confiable.",
        cta1: "Pedir Cotización",
        cta2: "Agendar Ahora",
        cta3: "WhatsApp"
      },
      services: {
        title: "Servicios Más Solicitados",
        subtitle: "Elige el servicio que necesitas"
      },
      whyChoose: {
        title: "¿Por qué elegir Beacon Solutions Hub?",
        subtitle: "Tu tranquilidad es nuestra prioridad"
      },
      testimonials: {
        title: "Lo que dicen nuestros clientes",
        subtitle: "Más de 500 clientes satisfechos en Orlando"
      },
      finalCta: {
        title: "¿Listo para comenzar?",
        subtitle: "Recibe tu cotización en hasta 2 horas"
      }
    }
  };

  const currentContent = content[language as keyof typeof content];

  const services = [
    {
      title: "Beacon Pintura Residencial",
      description: "Pintura interna e externa com acabamento profissional",
      price: "A partir de $299",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/e3c1bd8e-cebe-412a-b5c8-f2141687cca7.png"
    },
    {
      title: "Beacon Pressure Washing",
      description: "Limpeza de calçadas, telhados e fachadas",
      price: "A partir de $149",
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop&crop=center"
    },
    {
      title: "Beacon Limpeza e Higienização de Estofados",
      description: "Higienização profunda de sofás, colchões e carpetes",
      price: "A partir de $89",
      image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop&crop=center"
    },
    {
      title: "Beacon Limpeza Residencial",
      description: "Limpeza completa e Airbnb cleaning",
      price: "A partir de $120",
      image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=400&h=300&fit=crop&crop=center"
    },
    {
      title: "Beacon Handyman",
      description: "Pequenos reparos e manutenção residencial",
      price: "A partir de $75",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/c2ab8ce6-4ec6-4c8e-ac88-d7c4bb558606.png"
    },
    {
      title: "Beacon Limpeza de Piscina",
      description: "Manutenção e limpeza completa de piscinas",
      price: "A partir de $95",
      image: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&h=300&fit=crop&crop=center"
    }
  ];

  const benefits = [
    {
      icon: <Users className="h-8 w-8 text-blue-600" />,
      title: "Profissionais Verificados",
      description: "Todos os prestadores passam por verificação de antecedentes e qualificação"
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-600" />,
      title: "Orçamento Transparente",
      description: "Preços claros sem surpresas. Você sabe exatamente o que vai pagar"
    },
    {
      icon: <Clock className="h-8 w-8 text-blue-600" />,
      title: "Pontualidade Garantida",
      description: "Chegamos no horário combinado ou você recebe desconto"
    },
    {
      icon: <Award className="h-8 w-8 text-blue-600" />,
      title: "Suporte Centralizado",
      description: "Um único contato para todos os serviços. Suporte rápido e eficiente"
    }
  ];

  const testimonials = [
    {
      name: "Maria Silva",
      service: "Pintura Residencial",
      rating: 5,
      comment: "Excelente trabalho! Pintaram minha casa toda em 2 dias. Muito profissionais e pontuais.",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/af5a8770-3c82-4898-85dd-6fe435fea5b2.png"
    },
    {
      name: "John Martinez",
      service: "Pressure Washing",
      rating: 5,
      comment: "Amazing service! My driveway looks brand new. Highly recommend Beacon Solutions.",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/fdcf0e4a-7ba8-4382-8ccc-cd22bf573d0d.png"
    },
    {
      name: "Ana Rodriguez",
      service: "Limpeza de Estofados",
      rating: 5,
      comment: "Mi sofá quedó como nuevo. Servicio rápido y muy profesional. Los recomiendo 100%.",
      image: "https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/bdd9e745-c02b-4b48-b137-5f1fc38ef389.png"
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Language Selector */}
      <div className="bg-gray-50 py-2">
        <div className="container mx-auto px-4 flex justify-end">
          <Select value={language} onValueChange={setLanguage}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pt">🇧🇷 Português</SelectItem>
              <SelectItem value="en">🇺🇸 English</SelectItem>
              <SelectItem value="es">🇪🇸 Español</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="mb-6">
                <img 
                  src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/a681aede-387c-4d3b-a0af-eeaa20bcb968.png" 
                  alt="Beacon Solutions Hub Logo" 
                  className="h-16 mb-6"
                />
              </div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
                {currentContent.hero.title}
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                {currentContent.hero.subtitle}
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  className="bg-white text-blue-900 hover:bg-gray-100"
                  onClick={() => document.getElementById('quote-form')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  {currentContent.hero.cta1}
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:text-blue-900"
                  onClick={() => window.location.href = '/services'}
                >
                  {currentContent.hero.cta2}
                </Button>
                <Button 
                  size="lg" 
                  className="bg-green-600 hover:bg-green-700"
                  onClick={() => window.open('https://wa.me/14071234567?text=Olá! Gostaria de solicitar informações sobre os serviços da Beacon Solutions Hub.', '_blank')}
                >
                  <MessageCircle className="mr-2 h-5 w-5" />
                  {currentContent.hero.cta3}
                </Button>
              </div>
              <div className="mt-8 flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span>Orçamento em 2h</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span>Profissionais verificados</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-400" />
                  <span>Orlando e região</span>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/31d511d5-d125-436e-9b8e-9dcd52f0d53b.png" 
                alt="Professional home services team" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-lg shadow-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="h-5 w-5 text-yellow-500 fill-current" />
                  <span className="font-bold">4.9/5</span>
                </div>
                <p className="text-sm text-gray-600">500+ clientes satisfeitos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {currentContent.services.title}
            </h2>
            <p className="text-xl text-gray-600">
              {currentContent.services.subtitle}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center mb-4">
                    <Badge variant="secondary" className="text-blue-700 bg-blue-50">
                      {service.price}
                    </Badge>
                  </div>
                  <Button 
                    className="w-full"
                    onClick={() => window.open(`https://wa.me/16892970260?text=Olá! Gostaria de solicitar um orçamento para ${service.title}. Preço estimado: ${service.price}`, '_blank')}
                  >
                    Solicitar Orçamento
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => window.location.href = '/services'}
              className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
            >
              Ver Todos os Serviços (15 disponíveis)
            </Button>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {currentContent.whyChoose.title}
            </h2>
            <p className="text-xl text-gray-600">
              {currentContent.whyChoose.subtitle}
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center">
                <div className="bg-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4 shadow-md">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {benefit.title}
                </h3>
                <p className="text-gray-600">
                  {benefit.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Before/After Gallery */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Antes e Depois
            </h2>
            <p className="text-xl text-gray-600">
              Veja a transformação que fazemos em sua casa
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="relative group">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/d34fbc11-941d-4ba4-bc0f-2d17a71c6f35.png" 
                alt="Antes e depois - Pintura"
                className="w-full h-64 object-cover rounded-lg"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <span className="text-white font-semibold">Pintura Residencial</span>
              </div>
            </div>
            <div className="relative group">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/b0359f19-0af8-4f61-b544-5d45f47bd134.png" 
                alt="Antes e depois - Pressure Washing"
                className="w-full h-64 object-cover rounded-lg"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <span className="text-white font-semibold">Pressure Washing</span>
              </div>
            </div>
            <div className="relative group">
              <img 
                src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/8a48a119-726b-4449-9cc5-816578ad36e9.png" 
                alt="Antes e depois - Limpeza de Estofados"
                className="w-full h-64 object-cover rounded-lg"
              />
              <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                <span className="text-white font-semibold">Limpeza de Estofados</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {currentContent.testimonials.title}
            </h2>
            <p className="text-xl text-gray-600">
              {currentContent.testimonials.subtitle}
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <img 
                      src={testimonial.image} 
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full mr-4"
                    />
                    <div>
                      <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                      <p className="text-sm text-gray-600">{testimonial.service}</p>
                    </div>
                  </div>
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-500 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic">"{testimonial.comment}"</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                {currentContent.finalCta.title}
              </h2>
              <p className="text-xl text-blue-100">
                {currentContent.finalCta.subtitle}
              </p>
            </div>
            <Card className="bg-white text-gray-900" id="quote-form">
              <CardHeader>
                <CardTitle className="text-center">Solicite seu orçamento gratuito</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o serviço" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pintura">Pintura Residencial</SelectItem>
                    <SelectItem value="pressure">Pressure Washing</SelectItem>
                    <SelectItem value="estofados">Limpeza de Estofados</SelectItem>
                    <SelectItem value="limpeza">Limpeza Residencial</SelectItem>
                    <SelectItem value="handyman">Handyman</SelectItem>
                    <SelectItem value="piscina">Limpeza de Piscina</SelectItem>
                  </SelectContent>
                </Select>
                <Textarea placeholder="Descreva o que você precisa..." />
                <Button 
                  className="w-full bg-blue-900 hover:bg-blue-800"
                  onClick={() => {
                    const nome = (document.querySelector('input[placeholder="Seu nome"]') as HTMLInputElement)?.value;
                    const telefone = (document.querySelector('input[placeholder="Telefone"]') as HTMLInputElement)?.value;
                    const email = (document.querySelector('input[placeholder="E-mail"]') as HTMLInputElement)?.value;
                    const descricao = (document.querySelector('textarea[placeholder="Descreva o que você precisa..."]') as HTMLTextAreaElement)?.value;
                    
                    const mensagem = `Olá! Gostaria de solicitar um orçamento.
Nome: ${nome || 'Não informado'}
Telefone: ${telefone || 'Não informado'}
E-mail: ${email || 'Não informado'}
Descrição: ${descricao || 'Não informado'}`;
                    
                    window.open(`https://wa.me/16892970260?text=${encodeURIComponent(mensagem)}`, '_blank');
                  }}
                >
                  Enviar Solicitação
                </Button>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">Ou entre em contato diretamente:</p>
                  <div className="flex justify-center gap-4">
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => window.open('tel:+16892970260', '_self')}
                    >
                      <Phone className="h-4 w-4" />
                      (407) 123-4567
                    </Button>
                    <Button 
                      className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
                      onClick={() => window.open('https://wa.me/16892970260?text=Olá! Gostaria de falar sobre os serviços da Beacon Solutions Hub.', '_blank')}
                    >
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
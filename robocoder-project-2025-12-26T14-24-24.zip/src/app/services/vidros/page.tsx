"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Star, CheckCircle, Clock, Shield, Award, Phone, MessageCircle, Droplets, Sparkles } from "lucide-react";

export default function VidrosPage() {
  const [selectedPackage, setSelectedPackage] = useState("basico");

  const packages = [
    {
      id: "basico",
      name: "Limpeza Básica",
      price: "A partir de $65",
      duration: "1-2 horas",
      features: [
        "Até 10 janelas internas",
        "Limpeza com produtos profissionais",
        "Remoção de manchas básicas",
        "Secagem sem riscos",
        "Limpeza de peitoris"
      ]
    },
    {
      id: "completo",
      name: "Limpeza Completa",
      price: "A partir de $120",
      duration: "2-3 horas",
      features: [
        "Janelas internas e externas",
        "Limpeza de trilhos e molduras",
        "Remoção de manchas difíceis",
        "Tratamento anti-manchas",
        "Limpeza de telas (se aplicável)",
        "Até 20 janelas"
      ],
      popular: true
    },
    {
      id: "premium",
      name: "Serviço Premium",
      price: "A partir de $199",
      duration: "3-4 horas",
      features: [
        "Casa completa (ilimitado)",
        "Janelas internas e externas",
        "Limpeza profunda de trilhos",
        "Tratamento protetor",
        "Limpeza de espelhos",
        "Portas de vidro",
        "Garantia de 30 dias"
      ]
    }
  ];

  const services = [
    {
      title: "Janelas Internas",
      description: "Limpeza completa das janelas por dentro, incluindo vidros, molduras e peitoris",
      image: "https://placehold.co/300x200?text=Interior+window+cleaning+crystal+clear+professional"
    },
    {
      title: "Janelas Externas",
      description: "Limpeza externa com equipamentos especializados para acesso seguro",
      image: "https://placehold.co/300x200?text=Exterior+window+cleaning+professional+equipment+safe"
    },
    {
      title: "Trilhos e Molduras",
      description: "Limpeza detalhada de trilhos, molduras e cantos de difícil acesso",
      image: "https://placehold.co/300x200?text=Window+tracks+frames+detailed+cleaning+maintenance"
    },
    {
      title: "Portas de Vidro",
      description: "Limpeza especializada de portas de vidro e divisórias",
      image: "https://placehold.co/300x200?text=Glass+doors+sliding+cleaning+streak+free+finish"
    }
  ];

  const faqs = [
    {
      question: "Com que frequência devo limpar as janelas?",
      answer: "Recomendamos limpeza a cada 3-6 meses para residências. Para casas próximas ao mar ou áreas com muito vento, pode ser necessário mais frequentemente."
    },
    {
      question: "Vocês limpam janelas de segundo andar?",
      answer: "Sim! Temos equipamentos especializados e profissionais treinados para limpeza segura em alturas. Seguimos todos os protocolos de segurança."
    },
    {
      question: "E se chover depois da limpeza?",
      answer: "Chuva normal não afeta janelas bem limpas. Se houver problemas devido ao clima nas primeiras 24h, retornamos gratuitamente."
    },
    {
      question: "Que produtos vocês usam?",
      answer: "Utilizamos produtos profissionais eco-friendly que não deixam resíduos e são seguros para plantas e animais."
    },
    {
      question: "Limpam as telas das janelas?",
      answer: "Sim! A limpeza de telas está incluída no pacote completo e premium. Para o básico, pode ser adicionada por taxa extra."
    }
  ];

  const beforeAfter = [
    {
      title: "Janelas da Sala - Vista Cristalina",
      before: "https://placehold.co/400x300?text=Before+dirty+windows+streaks+spots+unclear+view",
      after: "https://placehold.co/400x300?text=After+crystal+clear+windows+perfect+transparency"
    },
    {
      title: "Porta de Vidro - Sem Manchas",
      before: "https://placehold.co/400x300?text=Before+glass+door+fingerprints+water+spots+dirty",
      after: "https://placehold.co/400x300?text=After+glass+door+spotless+crystal+clear+finish"
    },
    {
      title: "Janelas Externas - Brilho Profissional",
      before: "https://placehold.co/400x300?text=Before+exterior+windows+weather+stains+dirt",
      after: "https://placehold.co/400x300?text=After+exterior+windows+professional+shine+clean"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link>
            <span className="text-gray-400">/</span>
            <Link href="/services" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900">Limpeza de Vidros</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Link href="/services">
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Voltar aos Serviços
                  </Button>
                </Link>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Beacon Limpeza de Vidros
              </h1>
              <p className="text-xl text-blue-100 mb-6">
                Janelas cristalinas que transformam a luz natural da sua casa. 
                Limpeza profissional sem riscos, manchas ou resíduos.
              </p>
              <div className="flex items-center gap-6 mb-8">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="font-semibold">4.7/5</span>
                  <span className="text-blue-200">(87 avaliações)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-300" />
                  <span>1-4 horas</span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                  Solicitar Orçamento
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                  Ver Galeria
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://placehold.co/600x500?text=Professional+window+cleaning+crystal+clear+results" 
                alt="Beacon Limpeza de Vidros" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-lg shadow-lg">
                <div className="text-2xl font-bold text-blue-600">A partir de</div>
                <div className="text-3xl font-bold">$65</div>
                <div className="text-sm text-gray-600">até 10 janelas</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Pacotes de Limpeza
            </h2>
            <p className="text-xl text-gray-600">
              Escolha o serviço ideal para suas janelas
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card key={pkg.id} className={`relative ${pkg.popular ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}>
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-xl">{pkg.name}</CardTitle>
                  <div className="text-3xl font-bold text-blue-600">{pkg.price}</div>
                  <CardDescription>Duração: {pkg.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    variant={pkg.popular ? "default" : "outline"}
                    onClick={() => setSelectedPackage(pkg.id)}
                  >
                    Escolher {pkg.name}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Services Details */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nossos Serviços de Limpeza
            </h2>
            <p className="text-xl text-gray-600">
              Cobertura completa para todos os tipos de vidros
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="text-center">
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{service.title}</CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                O que está incluído
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Sparkles className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Limpeza Profissional</h3>
                    <p className="text-gray-600">Produtos especializados que removem manchas, resíduos e deixam vidros cristalinos.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Shield className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Equipamentos Seguros</h3>
                    <p className="text-gray-600">Ferramentas profissionais para acesso seguro a janelas altas e de difícil acesso.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Droplets className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Acabamento Perfeito</h3>
                    <p className="text-gray-600">Técnica profissional que garante resultado sem riscos, manchas ou marcas.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Produtos Eco-Friendly</h3>
                    <p className="text-gray-600">Produtos biodegradáveis, seguros para plantas, animais e meio ambiente.</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://placehold.co/600x500?text=Professional+window+cleaning+process+eco+friendly+products" 
                alt="Processo de limpeza profissional" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Before/After Gallery */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Antes e Depois
            </h2>
            <p className="text-xl text-gray-600">
              A diferença que faz uma limpeza profissional
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {beforeAfter.map((item, index) => (
              <div key={index} className="space-y-4">
                <h3 className="font-semibold text-center">{item.title}</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <img 
                      src={item.before} 
                      alt="Antes" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
                      ANTES
                    </div>
                  </div>
                  <div className="relative">
                    <img 
                      src={item.after} 
                      alt="Depois" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-medium">
                      DEPOIS
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Perguntas Frequentes
              </h2>
              <p className="text-xl text-gray-600">
                Tire suas dúvidas sobre limpeza de vidros
              </p>
            </div>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-gray-50 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-medium">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Janelas Cristalinas Te Esperam!
              </h2>
              <p className="text-xl text-blue-100">
                Solicite seu orçamento gratuito e veja a diferença da limpeza profissional
              </p>
            </div>
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-center">Orçamento Gratuito - Limpeza de Vidros</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Input placeholder="Endereço completo" />
                <div className="grid md:grid-cols-2 gap-4">
                  <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha o pacote" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basico">Limpeza Básica</SelectItem>
                      <SelectItem value="completo">Limpeza Completa</SelectItem>
                      <SelectItem value="premium">Serviço Premium</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Número de janelas" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 janelas</SelectItem>
                      <SelectItem value="11-20">11-20 janelas</SelectItem>
                      <SelectItem value="21-30">21-30 janelas</SelectItem>
                      <SelectItem value="30+">Mais de 30 janelas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Detalhes adicionais (tipo de janelas, acesso, etc.)" />
                <Button className="w-full bg-blue-900 hover:bg-blue-800">
                  Solicitar Orçamento Gratuito
                </Button>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">Ou entre em contato diretamente:</p>
                  <div className="flex justify-center gap-4">
                    <Button variant="outline" className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      (407) 123-4567
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
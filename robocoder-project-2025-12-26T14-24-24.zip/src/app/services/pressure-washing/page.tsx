"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Star, CheckCircle, Clock, Shield, Award, Phone, MessageCircle, Droplets, Home, Fence } from "lucide-react";

export default function PressureWashingPage() {
  const [selectedService, setSelectedService] = useState("driveway");

  const services = [
    {
      id: "driveway",
      name: "Driveway Cleaning",
      price: "A partir de $149",
      duration: "2-3 horas",
      description: "Limpeza profunda de calçadas, garagens e áreas pavimentadas",
      features: [
        "Remoção de manchas de óleo",
        "Eliminação de mofo e algas",
        "Limpeza de juntas",
        "Tratamento anti-manchas",
        "Secagem rápida"
      ],
      image: "https://placehold.co/400x300?text=Driveway+pressure+washing+concrete+cleaning+professional"
    },
    {
      id: "house-washing",
      name: "House Washing",
      price: "A partir de $299",
      duration: "4-6 horas", 
      description: "Limpeza completa da fachada externa da casa",
      features: [
        "Soft wash para superfícies delicadas",
        "Pressure wash para áreas resistentes",
        "Limpeza de janelas externas",
        "Remoção de teias de aranha",
        "Proteção de plantas"
      ],
      image: "https://placehold.co/400x300?text=House+washing+exterior+cleaning+soft+wash+professional",
      popular: true
    },
    {
      id: "roof-washing",
      name: "Roof Washing (Soft Wash)",
      price: "A partir de $399",
      duration: "4-5 horas",
      description: "Limpeza suave e segura de telhados com técnica soft wash",
      features: [
        "Técnica soft wash especializada",
        "Remoção de algas e mofo",
        "Produtos biodegradáveis",
        "Inspeção de segurança",
        "Garantia de 1 ano"
      ],
      image: "https://placehold.co/400x300?text=Roof+soft+wash+cleaning+algae+mold+removal+safe"
    },
    {
      id: "gutter-cleaning",
      name: "Gutter Cleaning",
      price: "A partir de $129",
      duration: "2-3 horas",
      description: "Limpeza completa de calhas e sistema de drenagem",
      features: [
        "Remoção de folhas e detritos",
        "Limpeza de downspouts",
        "Verificação de vazamentos",
        "Teste de fluxo de água",
        "Relatório de condição"
      ],
      image: "https://placehold.co/400x300?text=Gutter+cleaning+debris+removal+drainage+maintenance"
    },
    {
      id: "deck-fence",
      name: "Deck & Fence Cleaning",
      price: "A partir de $199",
      duration: "3-4 horas",
      description: "Limpeza e restauração de decks e cercas de madeira",
      features: [
        "Pressure wash ajustado",
        "Remoção de mofo e manchas",
        "Preparação para stain/selador",
        "Proteção de plantas",
        "Limpeza de hardware"
      ],
      image: "https://placehold.co/400x300?text=Deck+fence+cleaning+wood+restoration+pressure+wash"
    }
  ];

  const techniques = [
    {
      title: "Pressure Washing",
      description: "Alta pressão para superfícies resistentes como concreto e tijolo",
      icon: <Droplets className="h-8 w-8 text-blue-600" />,
      applications: ["Calçadas", "Garagens", "Pátios de concreto", "Muros de tijolo"]
    },
    {
      title: "Soft Washing",
      description: "Baixa pressão com produtos especializados para superfícies delicadas",
      icon: <Home className="h-8 w-8 text-green-600" />,
      applications: ["Telhados", "Siding de vinil", "Janelas", "Superfícies pintadas"]
    }
  ];

  const faqs = [
    {
      question: "Qual a diferença entre pressure wash e soft wash?",
      answer: "Pressure wash usa alta pressão para superfícies resistentes como concreto. Soft wash usa baixa pressão com produtos especializados para superfícies delicadas como telhados e siding."
    },
    {
      question: "É seguro para plantas e jardins?",
      answer: "Sim! Protegemos todas as plantas antes do serviço e usamos produtos biodegradáveis. Também regamos as plantas após o serviço como precaução extra."
    },
    {
      question: "Com que frequência devo fazer pressure washing?",
      answer: "Recomendamos anualmente para a maioria das superfícies. Áreas com muito tráfego ou exposição podem precisar de limpeza semestral."
    },
    {
      question: "Vocês trazem água e equipamentos?",
      answer: "Sim! Trazemos todos os equipamentos profissionais. Precisamos apenas de acesso a uma tomada elétrica e ponto de água."
    },
    {
      question: "Fazem limpeza em dias chuvosos?",
      answer: "Não realizamos serviços durante chuva por segurança. Reagendamos sem custo adicional se o tempo não colaborar."
    }
  ];

  const beforeAfter = [
    {
      title: "Calçada - Remoção Completa de Manchas",
      before: "https://placehold.co/400x300?text=Before+dirty+driveway+oil+stains+algae+mold",
      after: "https://placehold.co/400x300?text=After+clean+driveway+spotless+professional+finish"
    },
    {
      title: "Fachada - House Washing Completo",
      before: "https://placehold.co/400x300?text=Before+dirty+house+exterior+mold+stains+weathered",
      after: "https://placehold.co/400x300?text=After+clean+house+exterior+fresh+like+new"
    },
    {
      title: "Deck - Restauração de Madeira",
      before: "https://placehold.co/400x300?text=Before+weathered+deck+mold+stains+gray+wood",
      after: "https://placehold.co/400x300?text=After+restored+deck+clean+wood+ready+staining"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link>
            <span className="text-gray-400">/</span>
            <Link href="/services" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900">Pressure Washing & Soft Wash</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Link href="/services">
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Voltar aos Serviços
                  </Button>
                </Link>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Beacon Pressure Washing & Soft Wash
              </h1>
              <p className="text-xl text-blue-100 mb-6">
                Limpeza profissional para todas as superfícies externas. 
                Pressure washing para áreas resistentes, soft wash para superfícies delicadas.
              </p>
              <div className="flex items-center gap-6 mb-8">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="font-semibold">4.8/5</span>
                  <span className="text-blue-200">(203 avaliações)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-300" />
                  <span>2-6 horas</span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                  Solicitar Orçamento
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                  Ver Galeria
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://placehold.co/600x500?text=Professional+pressure+washing+house+driveway+cleaning" 
                alt="Beacon Pressure Washing" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-lg shadow-lg">
                <div className="text-2xl font-bold text-blue-600">A partir de</div>
                <div className="text-3xl font-bold">$129</div>
                <div className="text-sm text-gray-600">por serviço</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nossos Serviços de Limpeza Externa
            </h2>
            <p className="text-xl text-gray-600">
              Soluções completas para todas as superfícies externas
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service) => (
              <Card key={service.id} className={`relative ${service.popular ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}>
                {service.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-lg">{service.name}</CardTitle>
                    <Badge variant="secondary" className="text-blue-700 bg-blue-50">
                      {service.price}
                    </Badge>
                  </div>
                  <CardDescription>{service.description}</CardDescription>
                  <div className="text-sm text-gray-500">Duração: {service.duration}</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-4">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2 text-sm">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    onClick={() => setSelectedService(service.id)}
                  >
                    Solicitar Orçamento
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Techniques Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nossas Técnicas Especializadas
            </h2>
            <p className="text-xl text-gray-600">
              Método correto para cada tipo de superfície
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8">
            {techniques.map((technique, index) => (
              <Card key={index} className="h-full">
                <CardHeader>
                  <div className="flex items-center gap-4 mb-4">
                    {technique.icon}
                    <CardTitle className="text-2xl">{technique.title}</CardTitle>
                  </div>
                  <CardDescription className="text-lg">{technique.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <h4 className="font-semibold mb-3">Aplicações:</h4>
                  <ul className="space-y-2">
                    {technique.applications.map((app, appIndex) => (
                      <li key={appIndex} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span>{app}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                O que está incluído
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Shield className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Equipamentos Profissionais</h3>
                    <p className="text-gray-600">Máquinas de alta pressão e sistemas de soft wash com controle preciso de pressão.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Droplets className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Produtos Especializados</h3>
                    <p className="text-gray-600">Detergentes biodegradáveis e produtos específicos para cada tipo de sujeira.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Home className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Proteção Completa</h3>
                    <p className="text-gray-600">Cobrimos plantas, móveis externos e superfícies sensíveis durante o serviço.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Garantia de Satisfação</h3>
                    <p className="text-gray-600">Se não ficar satisfeito, retornamos gratuitamente em até 48 horas.</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://placehold.co/600x500?text=Professional+pressure+washing+equipment+techniques+safety" 
                alt="Equipamentos e técnicas profissionais" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Before/After Gallery */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Transformações Impressionantes
            </h2>
            <p className="text-xl text-gray-600">
              Veja o poder da limpeza profissional
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {beforeAfter.map((item, index) => (
              <div key={index} className="space-y-4">
                <h3 className="font-semibold text-center">{item.title}</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <img 
                      src={item.before} 
                      alt="Antes" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
                      ANTES
                    </div>
                  </div>
                  <div className="relative">
                    <img 
                      src={item.after} 
                      alt="Depois" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-medium">
                      DEPOIS
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Perguntas Frequentes
              </h2>
              <p className="text-xl text-gray-600">
                Tire suas dúvidas sobre pressure washing
              </p>
            </div>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-gray-50 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-medium">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Transforme Sua Propriedade!
              </h2>
              <p className="text-xl text-blue-100">
                Solicite seu orçamento gratuito e veja a diferença da limpeza profissional
              </p>
            </div>
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-center">Orçamento Gratuito - Pressure Washing</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Input placeholder="Endereço completo" />
                <div className="grid md:grid-cols-2 gap-4">
                  <Select value={selectedService} onValueChange={setSelectedService}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tipo de serviço" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="driveway">Driveway Cleaning</SelectItem>
                      <SelectItem value="house-washing">House Washing</SelectItem>
                      <SelectItem value="roof-washing">Roof Washing</SelectItem>
                      <SelectItem value="gutter-cleaning">Gutter Cleaning</SelectItem>
                      <SelectItem value="deck-fence">Deck & Fence Cleaning</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Tamanho da propriedade" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pequena">Pequena (até 1500 sq ft)</SelectItem>
                      <SelectItem value="media">Média (1500-2500 sq ft)</SelectItem>
                      <SelectItem value="grande">Grande (2500+ sq ft)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Descreva as áreas que precisam de limpeza..." />
                <Button className="w-full bg-blue-900 hover:bg-blue-800">
                  Solicitar Orçamento Gratuito
                </Button>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">Ou entre em contato diretamente:</p>
                  <div className="flex justify-center gap-4">
                    <Button variant="outline" className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      (407) 123-4567
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
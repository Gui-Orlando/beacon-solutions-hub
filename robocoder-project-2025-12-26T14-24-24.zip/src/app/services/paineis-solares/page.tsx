"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Star, CheckCircle, Clock, Shield, Award, Phone, MessageCircle, Zap, Sun, Leaf } from "lucide-react";

export default function PaineisSolaresPage() {
  const [selectedPackage, setSelectedPackage] = useState("manutencao");

  const packages = [
    {
      id: "limpeza-unica",
      name: "Limpeza Única",
      price: "A partir de $149",
      duration: "2-3 horas",
      features: [
        "Limpeza completa dos painéis",
        "Remoção de sujeira e detritos",
        "Inspeção visual básica",
        "Relatório de eficiência",
        "Produtos especializados"
      ]
    },
    {
      id: "manutencao",
      name: "Plano Semestral",
      price: "A partir de $249",
      duration: "2x por ano",
      features: [
        "2 limpezas por ano",
        "Inspeção detalhada",
        "Monitoramento de eficiência",
        "Relatório técnico",
        "Desconto de 20%",
        "Prioridade no agendamento"
      ],
      popular: true
    },
    {
      id: "premium",
      name: "Plano Anual Premium",
      price: "A partir de $399",
      duration: "4x por ano",
      features: [
        "4 limpezas por ano",
        "Inspeção técnica completa",
        "Monitoramento contínuo",
        "Manutenção preventiva",
        "Relatórios trimestrais",
        "Garantia de eficiência",
        "Suporte prioritário"
      ]
    }
  ];

  const benefits = [
    {
      icon: <Zap className="h-8 w-8 text-yellow-500" />,
      title: "Máxima Eficiência",
      description: "Painéis limpos podem aumentar a eficiência em até 25%",
      stat: "+25%"
    },
    {
      icon: <Sun className="h-8 w-8 text-orange-500" />,
      title: "Maior Produção",
      description: "Mais energia solar capturada = maior economia na conta de luz",
      stat: "↑ Economia"
    },
    {
      icon: <Shield className="h-8 w-8 text-blue-500" />,
      title: "Proteção do Investimento",
      description: "Manutenção adequada prolonga a vida útil dos painéis",
      stat: "+10 anos"
    },
    {
      icon: <Leaf className="h-8 w-8 text-green-500" />,
      title: "Sustentabilidade",
      description: "Produtos eco-friendly que não danificam o meio ambiente",
      stat: "100% Eco"
    }
  ];

  const faqs = [
    {
      question: "Com que frequência devo limpar os painéis solares?",
      answer: "Recomendamos limpeza a cada 6 meses em condições normais. Em áreas com muito vento, poeira ou próximas ao mar, pode ser necessário limpeza trimestral."
    },
    {
      question: "A limpeza realmente aumenta a eficiência?",
      answer: "Sim! Painéis sujos podem perder 15-25% da eficiência. Nossa limpeza especializada restaura a capacidade máxima de captação solar."
    },
    {
      question: "Que produtos vocês usam?",
      answer: "Utilizamos apenas produtos específicos para painéis solares, sem abrasivos, que não danificam o revestimento anti-reflexo dos painéis."
    },
    {
      question: "É seguro limpar painéis no telhado?",
      answer: "Nossos profissionais são treinados em segurança para trabalho em altura e usam equipamentos de proteção adequados. Temos seguro completo."
    },
    {
      question: "Vocês fazem inspeção técnica?",
      answer: "Sim! Verificamos conexões, cabos, inversores e medimos a eficiência antes e depois da limpeza, fornecendo relatório completo."
    }
  ];

  const beforeAfter = [
    {
      title: "Painéis Residenciais - Eficiência Restaurada",
      before: "https://placehold.co/400x300?text=Before+dirty+solar+panels+dust+debris+low+efficiency",
      after: "https://placehold.co/400x300?text=After+clean+solar+panels+maximum+efficiency+crystal+clear"
    },
    {
      title: "Sistema Comercial - Produção Otimizada",
      before: "https://placehold.co/400x300?text=Before+commercial+solar+panels+accumulated+dirt",
      after: "https://placehold.co/400x300?text=After+commercial+solar+panels+professional+cleaning"
    },
    {
      title: "Manutenção Preventiva - Longevidade",
      before: "https://placehold.co/400x300?text=Before+solar+panels+maintenance+inspection+needed",
      after: "https://placehold.co/400x300?text=After+solar+panels+maintained+optimal+condition"
    }
  ];

  const process = [
    {
      step: "1",
      title: "Inspeção Inicial",
      description: "Avaliamos o estado dos painéis e medimos a eficiência atual"
    },
    {
      step: "2", 
      title: "Limpeza Especializada",
      description: "Remoção cuidadosa de sujeira sem danificar o revestimento"
    },
    {
      step: "3",
      title: "Verificação Técnica", 
      description: "Inspeção de cabos, conexões e componentes do sistema"
    },
    {
      step: "4",
      title: "Relatório Final",
      description: "Documentação da melhoria na eficiência e recomendações"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link>
            <span className="text-gray-400">/</span>
            <Link href="/services" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900">Limpeza de Painéis Solares</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-600 via-yellow-600 to-orange-500 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Link href="/services">
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Voltar aos Serviços
                  </Button>
                </Link>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Beacon Limpeza de Painéis Solares
              </h1>
              <p className="text-xl text-orange-100 mb-6">
                Maximize a eficiência dos seus painéis solares com limpeza especializada. 
                Mais energia, maior economia, investimento protegido.
              </p>
              <div className="flex items-center gap-6 mb-8">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-300 fill-current" />
                  <span className="font-semibold">4.8/5</span>
                  <span className="text-orange-200">(67 avaliações)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-orange-300" />
                  <span>2-4 horas</span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-orange-600 hover:bg-gray-100">
                  Solicitar Orçamento
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-orange-600">
                  Calcular Economia
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://placehold.co/600x500?text=Professional+solar+panel+cleaning+maximum+efficiency" 
                alt="Beacon Limpeza de Painéis Solares" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-lg shadow-lg">
                <div className="text-2xl font-bold text-orange-600">Até +25%</div>
                <div className="text-lg font-semibold">Eficiência</div>
                <div className="text-sm text-gray-600">com limpeza profissional</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Por que Limpar Painéis Solares?
            </h2>
            <p className="text-xl text-gray-600">
              Benefícios comprovados da manutenção adequada
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="flex justify-center mb-4">
                    {benefit.icon}
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-2">{benefit.stat}</div>
                  <CardTitle className="text-lg">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Planos de Manutenção
            </h2>
            <p className="text-xl text-gray-600">
              Escolha a frequência ideal para seus painéis
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card key={pkg.id} className={`relative ${pkg.popular ? 'ring-2 ring-orange-500 shadow-lg' : ''}`}>
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-orange-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-xl">{pkg.name}</CardTitle>
                  <div className="text-3xl font-bold text-orange-600">{pkg.price}</div>
                  <CardDescription>Frequência: {pkg.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    variant={pkg.popular ? "default" : "outline"}
                    onClick={() => setSelectedPackage(pkg.id)}
                  >
                    Escolher {pkg.name}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Nosso Processo Especializado
            </h2>
            <p className="text-xl text-gray-600">
              Metodologia profissional para máximos resultados
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            {process.map((item, index) => (
              <Card key={index} className="text-center">
                <CardHeader>
                  <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-xl font-bold text-orange-600">{item.step}</span>
                  </div>
                  <CardTitle className="text-lg">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Before/After Gallery */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Resultados Comprovados
            </h2>
            <p className="text-xl text-gray-600">
              Veja o impacto da limpeza profissional
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {beforeAfter.map((item, index) => (
              <div key={index} className="space-y-4">
                <h3 className="font-semibold text-center">{item.title}</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <img 
                      src={item.before} 
                      alt="Antes" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
                      ANTES
                    </div>
                  </div>
                  <div className="relative">
                    <img 
                      src={item.after} 
                      alt="Depois" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-medium">
                      DEPOIS
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Perguntas Frequentes
              </h2>
              <p className="text-xl text-gray-600">
                Tire suas dúvidas sobre limpeza de painéis solares
              </p>
            </div>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-gray-50 rounded-lg px-6">
                  <AccordionTrigger className="text-left font-medium">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-orange-600 to-yellow-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Maximize Sua Economia Solar!
              </h2>
              <p className="text-xl text-orange-100">
                Solicite uma avaliação gratuita e descubra quanto você pode economizar
              </p>
            </div>
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-center">Avaliação Gratuita - Painéis Solares</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Input placeholder="Endereço completo" />
                <div className="grid md:grid-cols-2 gap-4">
                  <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Tipo de serviço" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="limpeza-unica">Limpeza Única</SelectItem>
                      <SelectItem value="manutencao">Plano Semestral</SelectItem>
                      <SelectItem value="premium">Plano Anual Premium</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Quantidade de painéis" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-10">1-10 painéis</SelectItem>
                      <SelectItem value="11-20">11-20 painéis</SelectItem>
                      <SelectItem value="21-30">21-30 painéis</SelectItem>
                      <SelectItem value="30+">Mais de 30 painéis</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Informações adicionais sobre seu sistema solar..." />
                <Button className="w-full bg-orange-600 hover:bg-orange-700">
                  Solicitar Avaliação Gratuita
                </Button>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">Ou entre em contato diretamente:</p>
                  <div className="flex justify-center gap-4">
                    <Button variant="outline" className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      (407) 123-4567
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ArrowLeft, Star, CheckCircle, Clock, Shield, Award, Phone, MessageCircle } from "lucide-react";

export default function PinturaPage() {
  const [selectedPackage, setSelectedPackage] = useState("basico");

  const packages = [
    {
      id: "basico",
      name: "Pacote Básico",
      price: "A partir de $299",
      duration: "2-3 dias",
      features: [
        "Pintura de 1 cômodo",
        "Preparação básica das paredes",
        "1 demão de tinta",
        "Proteção de móveis",
        "Limpeza final"
      ]
    },
    {
      id: "completo",
      name: "Pacote Completo",
      price: "A partir de $899",
      duration: "4-5 dias",
      features: [
        "Pintura de até 3 cômodos",
        "Preparação completa (lixa/selador)",
        "2 demãos de tinta premium",
        "Pintura de tetos",
        "Proteção total de móveis",
        "Acabamento em portas e janelas",
        "Limpeza completa"
      ],
      popular: true
    },
    {
      id: "premium",
      name: "Pacote Premium",
      price: "A partir de $1,599",
      duration: "6-8 dias",
      features: [
        "Pintura completa da casa",
        "Preparação profissional",
        "Tintas premium importadas",
        "Acabamentos especiais",
        "Pintura externa (se aplicável)",
        "Garantia estendida de 2 anos",
        "Consultoria de cores"
      ]
    }
  ];

  const faqs = [
    {
      question: "Que tipo de tinta vocês usam?",
      answer: "Utilizamos apenas tintas de alta qualidade das marcas Sherwin-Williams, Benjamin Moore e Behr. Todas as tintas são de baixo VOC e seguras para ambientes internos."
    },
    {
      question: "Vocês fazem a preparação das paredes?",
      answer: "Sim! Incluímos lixamento, aplicação de selador, correção de pequenos furos e rachaduras. Para danos maiores, fornecemos orçamento separado."
    },
    {
      question: "Como protegem os móveis?",
      answer: "Cobrimos todos os móveis com plástico protetor e utilizamos fita especial que não danifica superfícies. Também protegemos pisos com lona."
    },
    {
      question: "Oferecem garantia?",
      answer: "Sim! Oferecemos garantia de 1 ano para pintura interna e 6 meses para externa contra defeitos de aplicação."
    },
    {
      question: "Posso escolher as cores?",
      answer: "Claro! Oferecemos consultoria gratuita de cores e você pode escolher qualquer cor disponível nas marcas que trabalhamos."
    }
  ];

  const beforeAfter = [
    {
      title: "Sala de Estar - Transformação Completa",
      before: "https://placehold.co/400x300?text=Before+living+room+old+paint+worn+walls",
      after: "https://placehold.co/400x300?text=After+living+room+fresh+paint+modern+colors"
    },
    {
      title: "Quarto Principal - Cores Relaxantes",
      before: "https://placehold.co/400x300?text=Before+bedroom+outdated+paint+dull+colors",
      after: "https://placehold.co/400x300?text=After+bedroom+calming+paint+elegant+finish"
    },
    {
      title: "Cozinha - Acabamento Profissional",
      before: "https://placehold.co/400x300?text=Before+kitchen+old+paint+stained+walls",
      after: "https://placehold.co/400x300?text=After+kitchen+fresh+paint+clean+modern"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Breadcrumb */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 text-sm">
            <Link href="/" className="text-gray-600 hover:text-blue-600">Início</Link>
            <span className="text-gray-400">/</span>
            <Link href="/services" className="text-gray-600 hover:text-blue-600">Serviços</Link>
            <span className="text-gray-400">/</span>
            <span className="text-gray-900">Pintura Residencial</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Link href="/services">
                  <Button variant="ghost" size="sm" className="text-white hover:bg-white/10">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Voltar aos Serviços
                  </Button>
                </Link>
              </div>
              <h1 className="text-4xl lg:text-5xl font-bold mb-6">
                Beacon Pintura Residencial
              </h1>
              <p className="text-xl text-blue-100 mb-6">
                Transforme sua casa com pintura profissional. Acabamento perfeito, 
                materiais premium e garantia de qualidade.
              </p>
              <div className="flex items-center gap-6 mb-8">
                <div className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="font-semibold">4.9/5</span>
                  <span className="text-blue-200">(127 avaliações)</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-300" />
                  <span>2-8 dias</span>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                  Solicitar Orçamento
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                  Ver Galeria
                </Button>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://placehold.co/600x500?text=Professional+house+painting+team+interior+exterior+quality" 
                alt="Beacon Pintura Residencial" 
                className="rounded-lg shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white text-gray-900 p-4 rounded-lg shadow-lg">
                <div className="text-2xl font-bold text-blue-600">A partir de</div>
                <div className="text-3xl font-bold">$299</div>
                <div className="text-sm text-gray-600">por cômodo</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Escolha o Pacote Ideal
            </h2>
            <p className="text-xl text-gray-600">
              Opções para todos os orçamentos e necessidades
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card key={pkg.id} className={`relative ${pkg.popular ? 'ring-2 ring-blue-500 shadow-lg' : ''}`}>
                {pkg.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-blue-600 text-white px-4 py-1">
                      Mais Popular
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-xl">{pkg.name}</CardTitle>
                  <div className="text-3xl font-bold text-blue-600">{pkg.price}</div>
                  <CardDescription>Duração: {pkg.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {pkg.features.map((feature, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className="w-full" 
                    variant={pkg.popular ? "default" : "outline"}
                    onClick={() => setSelectedPackage(pkg.id)}
                  >
                    Escolher {pkg.name}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* What's Included */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                O que está incluído
              </h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Shield className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Preparação Profissional</h3>
                    <p className="text-gray-600">Lixamento, selador, correção de imperfeições e proteção completa de móveis e pisos.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Award className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Tintas Premium</h3>
                    <p className="text-gray-600">Utilizamos apenas tintas de alta qualidade: Sherwin-Williams, Benjamin Moore e Behr.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Acabamento Perfeito</h3>
                    <p className="text-gray-600">Aplicação uniforme, cantos bem definidos e acabamento em portas, janelas e rodapés.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="bg-blue-100 rounded-full p-2 flex-shrink-0">
                    <Clock className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Garantia de Qualidade</h3>
                    <p className="text-gray-600">1 ano de garantia contra defeitos de aplicação e consultoria gratuita de cores.</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://placehold.co/600x500?text=Professional+painting+process+preparation+quality+materials" 
                alt="Processo de pintura profissional" 
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Before/After Gallery */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Antes e Depois
            </h2>
            <p className="text-xl text-gray-600">
              Veja a transformação que fazemos em sua casa
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {beforeAfter.map((item, index) => (
              <div key={index} className="space-y-4">
                <h3 className="font-semibold text-center">{item.title}</h3>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <img 
                      src={item.before} 
                      alt="Antes" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-medium">
                      ANTES
                    </div>
                  </div>
                  <div className="relative">
                    <img 
                      src={item.after} 
                      alt="Depois" 
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    <div className="absolute bottom-2 left-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-medium">
                      DEPOIS
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Perguntas Frequentes
              </h2>
              <p className="text-xl text-gray-600">
                Tire suas dúvidas sobre nosso serviço de pintura
              </p>
            </div>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg px-6">
                  <AccordionTrigger className="text-left font-medium">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-600">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Pronto para Transformar sua Casa?
              </h2>
              <p className="text-xl text-blue-100">
                Solicite seu orçamento gratuito e receba resposta em até 2 horas
              </p>
            </div>
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-center">Orçamento Gratuito - Pintura Residencial</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Input placeholder="Endereço completo" />
                <div className="grid md:grid-cols-2 gap-4">
                  <Select value={selectedPackage} onValueChange={setSelectedPackage}>
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha o pacote" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basico">Pacote Básico</SelectItem>
                      <SelectItem value="completo">Pacote Completo</SelectItem>
                      <SelectItem value="premium">Pacote Premium</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Número de cômodos" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 cômodo</SelectItem>
                      <SelectItem value="2-3">2-3 cômodos</SelectItem>
                      <SelectItem value="4-5">4-5 cômodos</SelectItem>
                      <SelectItem value="casa-toda">Casa toda</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Descreva o que você precisa pintar (cômodos, cores preferidas, etc.)" />
                <Button className="w-full bg-blue-900 hover:bg-blue-800">
                  Solicitar Orçamento Gratuito
                </Button>
                <div className="text-center">
                  <p className="text-sm text-gray-600 mb-4">Ou entre em contato diretamente:</p>
                  <div className="flex justify-center gap-4">
                    <Button variant="outline" className="flex items-center gap-2">
                      <Phone className="h-4 w-4" />
                      (407) 123-4567
                    </Button>
                    <Button className="bg-green-600 hover:bg-green-700 flex items-center gap-2">
                      <MessageCircle className="h-4 w-4" />
                      WhatsApp
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
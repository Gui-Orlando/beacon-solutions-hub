"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRight, Star, CheckCircle } from "lucide-react";

export default function ServicesPage() {
  const [selectedCategory, setSelectedCategory] = useState("all");

  const serviceCategories = [
    { id: "all", name: "Todos os Serviços", count: 15 },
    { id: "limpeza", name: "Limpeza", count: 6 },
    { id: "pintura", name: "Pintura & Acabamento", count: 2 },
    { id: "manutencao", name: "Manutenção", count: 4 },
    { id: "especializados", name: "Especializados", count: 3 }
  ];

  const allServices = [
    {
      id: "pintura",
      category: "pintura",
      title: "Beacon Pintura Residencial",
      description: "Pintura interna e externa com acabamento profissional e materiais de qualidade",
      features: ["Pintura interna", "Pintura externa", "Preparação completa", "Proteção de móveis"],
      duration: "2-5 dias",
      priceRange: "A partir de $299",
      rating: 4.9,
      reviews: 127,
      image: "https://images.unsplash.com/photo-1562259949-e8e7689d7828?w=400&h=300&fit=crop&crop=center",
      href: "/services/pintura"
    },
    {
      id: "pressure-washing",
      category: "limpeza",
      title: "Beacon Pressure Washing & Soft Wash",
      description: "Limpeza profissional de calçadas, telhados, fachadas e superfícies externas",
      features: ["Driveway cleaning", "Roof washing", "House washing", "Deck cleaning"],
      duration: "4-8 horas",
      priceRange: "A partir de $149",
      rating: 4.8,
      reviews: 203,
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop&crop=center",
      href: "/services/pressure-washing"
    },
    {
      id: "estofados",
      category: "limpeza",
      title: "Beacon Limpeza e Higienização de Estofados",
      description: "Higienização profunda de sofás, colchões, carpetes e estofados em geral",
      features: ["Limpeza de sofás", "Higienização de colchões", "Carpetes", "Remoção de odores"],
      duration: "2-4 horas",
      priceRange: "A partir de $89",
      rating: 4.9,
      reviews: 156,
      image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=300&fit=crop&crop=center",
      href: "/services/estofados"
    },
    {
      id: "limpeza-residencial",
      category: "limpeza",
      title: "Beacon Limpeza Residencial & Airbnb",
      description: "Limpeza completa residencial, pós-construção e especializada para Airbnb",
      features: ["Deep cleaning", "Airbnb cleaning", "Pós-construção", "Housekeeping"],
      duration: "3-6 horas",
      priceRange: "A partir de $120",
      rating: 4.8,
      reviews: 189,
      image: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=400&h=300&fit=crop&crop=center",
      href: "/services/limpeza-residencial"
    },
    {
      id: "handyman",
      category: "manutencao",
      title: "Beacon Handyman",
      description: "Pequenos reparos e manutenção residencial com profissionais qualificados",
      features: ["Drywall patch", "Troca de torneiras", "Pequenos reparos", "Vedação"],
      duration: "2-6 horas",
      priceRange: "A partir de $75",
      rating: 4.7,
      reviews: 98,
      image: "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=400&h=300&fit=crop&crop=center",
      href: "/services/handyman"
    },
    {
      id: "piscina",
      category: "limpeza",
      title: "Beacon Limpeza de Piscina",
      description: "Manutenção completa e limpeza profissional de piscinas",
      features: ["Limpeza completa", "Tratamento químico", "Manutenção preventiva", "Inspeção"],
      duration: "1-2 horas",
      priceRange: "A partir de $95",
      rating: 4.8,
      reviews: 142,
      image: "https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=400&h=300&fit=crop&crop=center",
      href: "/services/piscina"
    },
    {
      id: "vidros",
      category: "limpeza",
      title: "Beacon Limpeza de Vidros",
      description: "Limpeza profissional de janelas internas e externas com acabamento perfeito",
      features: ["Janelas internas", "Janelas externas", "Trilhos", "Molduras"],
      duration: "2-4 horas",
      priceRange: "A partir de $65",
      rating: 4.7,
      reviews: 87,
      image: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=400&h=300&fit=crop&crop=center",
      href: "/services/vidros"
    },
    {
      id: "dog-walking",
      category: "especializados",
      title: "Beacon Dog Walking",
      description: "Passeio profissional para cães com cuidado e atenção personalizada",
      features: ["Passeio individual", "Passeio em grupo", "Visitas rápidas", "Relatório diário"],
      duration: "30-60 min",
      priceRange: "A partir de $25",
      rating: 4.9,
      reviews: 234,
      image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&h=300&fit=crop&crop=center",
      href: "/services/dog-walking"
    },
    {
      id: "gutter-guards",
      category: "manutencao",
      title: "Beacon Gutter Guards",
      description: "Instalação e manutenção de proteção para calhas",
      features: ["Instalação", "Manutenção", "Inspeção", "Limpeza preventiva"],
      duration: "4-8 horas",
      priceRange: "A partir de $299",
      rating: 4.6,
      reviews: 45,
      image: "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=400&h=300&fit=crop&crop=center",
      href: "/services/gutter-guards"
    },
    {
      id: "paineis-solares",
      category: "especializados",
      title: "Beacon Limpeza Painéis Solares",
      description: "Limpeza especializada de painéis solares para máxima eficiência",
      features: ["Limpeza especializada", "Sem abrasivos", "Plano semestral", "Inspeção"],
      duration: "2-4 horas",
      priceRange: "A partir de $149",
      rating: 4.8,
      reviews: 67,
      image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=400&h=300&fit=crop&crop=center",
      href: "/services/paineis-solares"
    },
    {
      id: "telhado",
      category: "manutencao",
      title: "Beacon Tratamento de Telhado",
      description: "Tratamento anti-mofo e algas com plano anual de manutenção",
      features: ["Soft wash", "Tratamento preventivo", "Inspeção", "Plano anual"],
      duration: "1 dia",
      priceRange: "A partir de $399",
      rating: 4.7,
      reviews: 78,
      image: "https://images.unsplash.com/photo-1504148455328-c376907d081c?w=400&h=300&fit=crop&crop=center",
      href: "/services/telhado"
    },
    {
      id: "epoxy",
      category: "pintura",
      title: "Beacon Epoxy Flooring",
      description: "Aplicação de piso epoxy para garagens e áreas internas selecionadas",
      features: ["Preparação de piso", "Aplicação epoxy", "Acabamentos", "Garantia"],
      duration: "2-3 dias",
      priceRange: "A partir de $599",
      rating: 4.8,
      reviews: 34,
      image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=300&fit=crop&crop=center",
      href: "/services/epoxy"
    },
    {
      id: "air-duct",
      category: "limpeza",
      title: "Beacon Air Duct Cleaning",
      description: "Limpeza e sanitização de dutos de ar condicionado",
      features: ["Limpeza de dutos", "Sanitização", "Grelhas", "Parceiro licenciado"],
      duration: "3-5 horas",
      priceRange: "A partir de $199",
      rating: 4.6,
      reviews: 56,
      image: "https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=400&h=300&fit=crop&crop=center",
      href: "/services/air-duct"
    },
    {
      id: "lixeiras",
      category: "limpeza",
      title: "Beacon Limpeza de Lixeiras",
      description: "Higienização e sanitização de lixeiras residenciais",
      features: ["Sanitização", "Desodorização", "Plano mensal", "Plano quinzenal"],
      duration: "15-30 min",
      priceRange: "A partir de $29",
      rating: 4.5,
      reviews: 123,
      image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=400&h=300&fit=crop&crop=center",
      href: "/services/lixeiras"
    },
    {
      id: "junk-removal",
      category: "especializados",
      title: "Beacon Junk Removal",
      description: "Remoção profissional de entulho, móveis velhos e lixo volumoso",
      features: ["Remoção de móveis", "Entulho residencial", "Limpeza pós-remoção", "Descarte responsável"],
      duration: "2-4 horas",
      priceRange: "A partir de $199",
      rating: 4.7,
      reviews: 89,
      image: "https://images.unsplash.com/photo-1566228015668-4c45dbc4e2f5?w=400&h=300&fit=crop&crop=center",
      href: "/services/junk-removal"
    }
  ];

  const filteredServices = selectedCategory === "all" 
    ? allServices 
    : allServices.filter(service => service.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Todos os Nossos Serviços
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Profissionais verificados para cada necessidade da sua casa. 
              Orçamento transparente e qualidade garantida.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                Solicitar Orçamento Múltiplo
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                Falar com Especialista
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Service Categories Filter */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap gap-4 justify-center">
            {serviceCategories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className="flex items-center gap-2"
              >
                {category.name}
                <Badge variant="secondary" className="ml-2">
                  {category.count}
                </Badge>
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredServices.map((service) => (
              <Card key={service.id} className="hover:shadow-lg transition-shadow bg-white">
                <div className="aspect-video relative overflow-hidden rounded-t-lg">
                  <img 
                    src={service.image} 
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-blue-600 text-white">
                      {service.priceRange}
                    </Badge>
                  </div>
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-lg">{service.title}</CardTitle>
                    <div className="flex items-center gap-1 text-sm">
                      <Star className="h-4 w-4 text-yellow-500 fill-current" />
                      <span className="font-medium">{service.rating}</span>
                      <span className="text-gray-500">({service.reviews})</span>
                    </div>
                  </div>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-sm text-gray-900 mb-2">Inclui:</h4>
                      <div className="grid grid-cols-2 gap-1">
                        {service.features.slice(0, 4).map((feature, index) => (
                          <div key={index} className="flex items-center gap-1 text-sm text-gray-600">
                            <CheckCircle className="h-3 w-3 text-green-500" />
                            <span>{feature}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="flex justify-between items-center text-sm text-gray-600">
                      <span>Duração: {service.duration}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button asChild className="flex-1">
                        <Link href={service.href}>
                          Ver Detalhes
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="outline" className="px-3">
                        Orçamento
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Quick Quote Section */}
      <section className="py-16 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold mb-4">
                Precisa de Múltiplos Serviços?
              </h2>
              <p className="text-xl text-blue-100">
                Solicite um orçamento combinado e economize até 15%
              </p>
            </div>
            <Card className="bg-white text-gray-900">
              <CardHeader>
                <CardTitle className="text-center">Orçamento Rápido - Múltiplos Serviços</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Input placeholder="Seu nome" />
                  <Input placeholder="Telefone" />
                </div>
                <Input placeholder="E-mail" />
                <Input placeholder="Endereço completo" />
                <div className="grid md:grid-cols-2 gap-4">
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Serviço principal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pintura">Pintura Residencial</SelectItem>
                      <SelectItem value="pressure">Pressure Washing</SelectItem>
                      <SelectItem value="estofados">Limpeza de Estofados</SelectItem>
                      <SelectItem value="limpeza">Limpeza Residencial</SelectItem>
                      <SelectItem value="handyman">Handyman</SelectItem>
                      <SelectItem value="piscina">Limpeza de Piscina</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Serviços adicionais" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vidros">Limpeza de Vidros</SelectItem>
                      <SelectItem value="dog-walking">Dog Walking</SelectItem>
                      <SelectItem value="gutter">Gutter Guards</SelectItem>
                      <SelectItem value="solar">Painéis Solares</SelectItem>
                      <SelectItem value="telhado">Tratamento Telhado</SelectItem>
                      <SelectItem value="epoxy">Epoxy Flooring</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Textarea placeholder="Descreva os serviços que você precisa..." />
                <Button className="w-full bg-blue-900 hover:bg-blue-800">
                  Solicitar Orçamento Combinado
                </Button>
                <p className="text-center text-sm text-gray-600">
                  Resposta em até 2 horas • Desconto para múltiplos serviços
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, Users, Shield, Star, Phone, MessageCircle, Calendar, FileText } from "lucide-react";

export default function ComoFuncionaPage() {
  const steps = [
    {
      number: "01",
      title: "Solicite seu Orçamento",
      description: "Preencha nosso formulário online ou entre em contato via WhatsApp. Descreva o serviço que você precisa.",
      icon: <FileText className="h-8 w-8 text-blue-600" />,
      details: [
        "Formulário rápido de 2 minutos",
        "Upload de fotos opcional",
        "Resposta em até 2 horas",
        "Orçamento sem compromisso"
      ]
    },
    {
      number: "02",
      title: "Receba Orçamento Detalhado",
      description: "Nossa equipe analisa sua solicitação e envia um orçamento transparente com todos os detalhes.",
      icon: <Calculator className="h-8 w-8 text-blue-600" />,
      details: [
        "Preços transparentes",
        "Detalhamento de materiais",
        "Prazo de execução",
        "Opções de pagamento"
      ]
    },
    {
      number: "03",
      title: "Agende o Serviço",
      description: "Escolha a data e horário que melhor funciona para você. Nosso sistema é flexível e conveniente.",
      icon: <Calendar className="h-8 w-8 text-blue-600" />,
      details: [
        "Agendamento online",
        "Horários flexíveis",
        "Confirmação automática",
        "Lembretes por SMS/email"
      ]
    },
    {
      number: "04",
      title: "Profissional Verificado",
      description: "Enviamos um profissional qualificado e verificado para realizar o serviço com excelência.",
      icon: <Users className="h-8 w-8 text-blue-600" />,
      details: [
        "Background check completo",
        "Profissionais treinados",
        "Uniformizados e identificados",
        "Equipamentos próprios"
      ]
    },
    {
      number: "05",
      title: "Serviço Executado",
      description: "O profissional executa o serviço com qualidade, pontualidade e cuidado com sua propriedade.",
      icon: <CheckCircle className="h-8 w-8 text-blue-600" />,
      details: [
        "Pontualidade garantida",
        "Materiais de qualidade",
        "Limpeza incluída",
        "Relatório de conclusão"
      ]
    },
    {
      number: "06",
      title: "Avaliação e Garantia",
      description: "Avalie o serviço e conte com nossa garantia de satisfação. Sua opinião é importante para nós.",
      icon: <Star className="h-8 w-8 text-blue-600" />,
      details: [
        "Sistema de avaliação",
        "Garantia de satisfação",
        "Suporte pós-serviço",
        "Programa de fidelidade"
      ]
    }
  ];

  const benefits = [
    {
      icon: <Shield className="h-12 w-12 text-blue-600" />,
      title: "Profissionais Verificados",
      description: "Todos os nossos prestadores passam por rigorosa verificação de antecedentes, qualificação técnica e treinamento em atendimento ao cliente."
    },
    {
      icon: <Clock className="h-12 w-12 text-blue-600" />,
      title: "Pontualidade Garantida",
      description: "Chegamos no horário combinado ou você recebe desconto. Valorizamos seu tempo e mantemos nossos compromissos."
    },
    {
      icon: <CheckCircle className="h-12 w-12 text-blue-600" />,
      title: "Qualidade Assegurada",
      description: "Utilizamos apenas materiais de primeira linha e seguimos protocolos rigorosos de qualidade em todos os serviços."
    },
    {
      icon: <Users className="h-12 w-12 text-blue-600" />,
      title: "Suporte Centralizado",
      description: "Um único contato para todos os serviços. Nossa equipe de suporte está sempre disponível para ajudar você."
    }
  ];

  const guarantees = [
    "✅ Satisfação 100% garantida ou reembolso",
    "✅ Profissionais com seguro e licença",
    "✅ Materiais de primeira qualidade",
    "✅ Pontualidade ou desconto automático",
    "✅ Limpeza completa incluída",
    "✅ Suporte 7 dias por semana"
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Como Funciona a Beacon Solutions Hub
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Processo simples, transparente e eficiente. Do orçamento à conclusão, 
              cuidamos de tudo para você ter a melhor experiência.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                Solicitar Orçamento
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                Falar com Especialista
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Process Steps */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Processo em 6 Passos Simples
            </h2>
            <p className="text-xl text-gray-600">
              Do primeiro contato até a conclusão do serviço
            </p>
          </div>
          
          <div className="space-y-12">
            {steps.map((step, index) => (
              <div key={index} className={`flex flex-col lg:flex-row gap-8 items-center ${index % 2 === 1 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2">
                  <Card className="h-full">
                    <CardHeader>
                      <div className="flex items-center gap-4 mb-4">
                        <div className="bg-blue-100 rounded-full p-3">
                          {step.icon}
                        </div>
                        <Badge variant="outline" className="text-2xl font-bold px-4 py-2">
                          {step.number}
                        </Badge>
                      </div>
                      <CardTitle className="text-2xl">{step.title}</CardTitle>
                      <CardDescription className="text-lg">{step.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {step.details.map((detail, detailIndex) => (
                          <li key={detailIndex} className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="text-gray-600">{detail}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
                <div className="lg:w-1/2">
                  <img 
                    src={`https://placehold.co/600x400?text=Step+${step.number}+${step.title.replace(/\s+/g, '+')}`}
                    alt={step.title}
                    className="rounded-lg shadow-lg w-full"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Por que Escolher a Beacon Solutions Hub?
            </h2>
            <p className="text-xl text-gray-600">
              Diferenciais que fazem toda a diferença na sua experiência
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center h-full">
                <CardHeader>
                  <div className="mx-auto mb-4">
                    {benefit.icon}
                  </div>
                  <CardTitle className="text-xl">{benefit.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantees Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Nossas Garantias
              </h2>
              <p className="text-xl text-gray-600">
                Sua tranquilidade é nossa prioridade
              </p>
            </div>
            <div className="grid md:grid-cols-2 gap-6">
              {guarantees.map((guarantee, index) => (
                <div key={index} className="flex items-center gap-3 p-4 bg-green-50 rounded-lg">
                  <span className="text-lg">{guarantee}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Transparency */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                Preços Transparentes
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Sem surpresas, sem taxas ocultas. Você sabe exatamente o que vai pagar 
                antes mesmo do serviço começar.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Orçamento detalhado por escrito</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Preço fixo acordado previamente</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Sem cobrança de deslocamento</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span>Materiais inclusos no preço</span>
                </div>
              </div>
            </div>
            <div>
              <img 
                src="https://placehold.co/600x500?text=Transparent+pricing+detailed+quote+no+hidden+fees"
                alt="Preços transparentes"
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-900 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl lg:text-4xl font-bold mb-6">
              Pronto para Começar?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Solicite seu orçamento gratuito agora e veja como é fácil 
              ter serviços de qualidade em sua casa.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-100">
                Solicitar Orçamento Gratuito
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-900">
                <Phone className="mr-2 h-5 w-5" />
                (407) 123-4567
              </Button>
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                <MessageCircle className="mr-2 h-5 w-5" />
                WhatsApp
              </Button>
            </div>
            <p className="text-blue-200">
              Atendimento 7 dias por semana • Resposta em até 2 horas
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

// Temporary Calculator component (would normally be imported)
function Calculator({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
    </svg>
  );
}
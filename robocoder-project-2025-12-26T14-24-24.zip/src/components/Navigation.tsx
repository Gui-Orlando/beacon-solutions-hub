"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Phone, MessageCircle } from "lucide-react";

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);

  const services = [
    { name: "Pintura Residencial", href: "/services/pintura" },
    { name: "Pressure Washing & Soft Wash", href: "/services/pressure-washing" },
    { name: "Limpeza e Higienização de Estofados", href: "/services/estofados" },
    { name: "Limpeza Residencial & Airbnb", href: "/services/limpeza-residencial" },
    { name: "Limpeza de Vidros", href: "/services/vidros" },
    { name: "Limpeza de Painéis Solares", href: "/services/paineis-solares" },
    { name: "Limpeza de Piscina", href: "/services/piscina" },
    { name: "Limpeza de Lixeiras", href: "/services/lixeiras" },
    { name: "Dog Walking", href: "/services/dog-walking" },
    { name: "Gutter Guards", href: "/services/gutter-guards" },
    { name: "Handyman", href: "/services/handyman" },
    { name: "Tratamento de Telhado", href: "/services/telhado" },
    { name: "Epoxy Flooring", href: "/services/epoxy" },
    { name: "Air Duct Cleaning", href: "/services/air-duct" },
    { name: "Junk Removal", href: "/services/junk-removal" },
  ];

  const handleWhatsAppClick = () => {
    window.open('https://wa.me/16892970260?text=Olá! Gostaria de falar sobre os serviços da Beacon Solutions Hub.', '_blank');
  };

  const handleQuoteClick = () => {
    const quoteForm = document.getElementById('quote-form');
    if (quoteForm) {
      quoteForm.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.location.href = '/#quote-form';
    }
  };

  return (
    <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center">
            <div className="text-2xl font-bold text-blue-900">
              BEACON SOLUTIONS HUB
            </div>
          </Link>

          <div className="hidden lg:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 font-medium">
              Início
            </Link>
            <div className="relative group">
              <button className="text-gray-700 hover:text-blue-600 font-medium">
                Serviços
              </button>
              <div className="absolute top-full left-0 mt-2 w-80 bg-white shadow-lg rounded-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 max-h-96 overflow-y-auto">
                <div className="py-2">
                  <div className="px-4 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider border-b">
                    Todos os Serviços (15)
                  </div>
                  {services.map((service) => (
                    <Link
                      key={service.href}
                      href={service.href}
                      className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 hover:text-blue-600"
                    >
                      {service.name}
                    </Link>
                  ))}
                  <div className="border-t mt-2 pt-2">
                    <Link
                      href="/services"
                      className="block px-4 py-2 text-sm font-medium text-blue-600 hover:bg-blue-50"
                    >
                      Ver Todos os Serviços →
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <Link href="/como-funciona" className="text-gray-700 hover:text-blue-600 font-medium">
              Como Funciona
            </Link>
            <Link href="/sobre" className="text-gray-700 hover:text-blue-600 font-medium">
              Sobre
            </Link>
            <Link href="/contato" className="text-gray-700 hover:text-blue-600 font-medium">
              Contato
            </Link>
          </div>

          <div className="hidden lg:flex items-center space-x-4">
            <div className="text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>(689) 297-0260</span>
              </div>
            </div>
            <Button 
              className="bg-green-600 hover:bg-green-700"
              onClick={handleWhatsAppClick}
            >
              <MessageCircle className="mr-2 h-4 w-4" />
              WhatsApp
            </Button>
            <Button onClick={handleQuoteClick}>
              Orçamento Grátis
            </Button>
          </div>

          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <div className="flex flex-col space-y-4 mt-8">
                <Link 
                  href="/" 
                  className="text-lg font-medium text-gray-700 hover:text-blue-600"
                  onClick={() => setIsOpen(false)}
                >
                  Início
                </Link>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-medium text-gray-900">Serviços</h3>
                  {services.map((service) => (
                    <Link
                      key={service.href}
                      href={service.href}
                      className="block pl-4 py-1 text-gray-600 hover:text-blue-600"
                      onClick={() => setIsOpen(false)}
                    >
                      {service.name}
                    </Link>
                  ))}
                </div>

                <Link 
                  href="/como-funciona" 
                  className="text-lg font-medium text-gray-700 hover:text-blue-600"
                  onClick={() => setIsOpen(false)}
                >
                  Como Funciona
                </Link>
                <Link 
                  href="/sobre" 
                  className="text-lg font-medium text-gray-700 hover:text-blue-600"
                  onClick={() => setIsOpen(false)}
                >
                  Sobre
                </Link>
                <Link 
                  href="/contato" 
                  className="text-lg font-medium text-gray-700 hover:text-blue-600"
                  onClick={() => setIsOpen(false)}
                >
                  Contato
                </Link>

                <div className="pt-4 border-t space-y-3">
                  <div className="flex items-center gap-2 text-gray-600">
                    <Phone className="h-4 w-4" />
                    <span>(407) 123-4567</span>
                  </div>
                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => {
                      setIsOpen(false);
                      handleWhatsAppClick();
                    }}
                  >
                    <MessageCircle className="mr-2 h-4 w-4" />
                    WhatsApp
                  </Button>
                  <Button 
                    className="w-full"
                    onClick={() => {
                      setIsOpen(false);
                      handleQuoteClick();
                    }}
                  >
                    Orçamento Grátis
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
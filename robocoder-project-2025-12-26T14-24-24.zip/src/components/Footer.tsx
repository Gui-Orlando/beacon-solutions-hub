import Link from "next/link";
import { Phone, MessageCircle, Mail, MapPin, Clock } from "lucide-react";

export function Footer() {
  const currentYear = new Date().getFullYear();

  const services = [
    "Pintura Residencial",
    "Pressure Washing",
    "Limpeza de Estofados",
    "Limpeza Residencial",
    "Handyman",
    "Limpeza de Piscina",
    "Limpeza de Vidros",
    "Dog Walking"
  ];

  const areas = [
    "Orlando",
    "Winter Park",
    "Kissimmee",
    "Altamonte Springs",
    "Oviedo",
    "Lake Mary",
    "Sanford",
    "Apopka"
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <img 
              src="https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/a8dc5d0d-3bf0-465e-84d5-d10bf3441f6d.png" 
              alt="Beacon Solutions Hub" 
              className="h-12 mb-6"
            />
            <p className="text-gray-300 mb-6">
              Vários prestadores diferentes, um único lugar e um único suporte. 
              Sua tranquilidade é nossa prioridade.
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-blue-400" />
                <span>(689) 297-0260</span>
              </div>
              <div className="flex items-center gap-3">
                <MessageCircle className="h-5 w-5 text-green-400" />
                <span>WhatsApp: (689) 297-0260</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-blue-400" />
                <span>info@beaconsolutionshub.com</span>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Nossos Serviços</h3>
            <ul className="space-y-2">
              {services.map((service, index) => (
                <li key={index}>
                  <Link href="#" className="text-gray-300 hover:text-white transition-colors">
                    {service}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Áreas Atendidas</h3>
            <ul className="space-y-2">
              {areas.map((area, index) => (
                <li key={index} className="text-gray-300">
                  {area}
                </li>
              ))}
            </ul>
            <div className="mt-6 flex items-start gap-3">
              <MapPin className="h-5 w-5 text-blue-400 mt-1" />
              <div>
                <p className="text-gray-300">Orlando, FL e região</p>
                <p className="text-sm text-gray-400">Raio de 30 milhas</p>
              </div>
            </div>
          </div>

          {/* Business Hours & Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Horário de Atendimento</h3>
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-blue-400" />
                <div>
                  <p className="text-gray-300">Segunda - Sexta: 7h - 19h</p>
                  <p className="text-gray-300">Sábado: 8h - 17h</p>
                  <p className="text-gray-300">Domingo: 9h - 15h</p>
                </div>
              </div>
            </div>
            
            <h4 className="font-semibold mb-4">Links Úteis</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/como-funciona" className="text-gray-300 hover:text-white transition-colors">
                  Como Funciona
                </Link>
              </li>
              <li>
                <Link href="/sobre" className="text-gray-300 hover:text-white transition-colors">
                  Sobre Nós
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-gray-300 hover:text-white transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/parceiros" className="text-gray-300 hover:text-white transition-colors">
                  Seja um Parceiro
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} Beacon Solutions Hub, LLC. Todos os direitos reservados.
            </div>
            <div className="flex space-x-6 text-sm">
              <Link href="/termos" className="text-gray-400 hover:text-white transition-colors">
                Termos de Uso
              </Link>
              <Link href="/privacidade" className="text-gray-400 hover:text-white transition-colors">
                Política de Privacidade
              </Link>
              <Link href="/cookies" className="text-gray-400 hover:text-white transition-colors">
                Cookies
              </Link>
            </div>
          </div>
          
          <div className="mt-6 text-center text-sm text-gray-500">
            <p>
              Alguns serviços podem exigir licenciamento específico. Nesses casos, 
              a Beacon Solutions Hub agenda com prestadores devidamente licenciados.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
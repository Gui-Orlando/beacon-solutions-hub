"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function LogoShowcase() {
  const [selectedLogo, setSelectedLogo] = useState(1);

  const logoOptions = [
    {
      id: 1,
      name: "Logo Farol Clássico (Inspirado no seu exemplo)",
      description: "Farol com ondas, transmite orientação, confiança e navegação segura - como no seu exemplo",
      component: (
        <div className="text-center">
          {/* Lighthouse Icon */}
          <div className="relative mb-3">
            <svg width="60" height="60" viewBox="0 0 100 100" className="mx-auto">
              {/* Lighthouse body */}
              <rect x="40" y="30" width="20" height="50" fill="#1e3a8a" />
              {/* Lighthouse top */}
              <rect x="38" y="25" width="24" height="8" fill="#1e3a8a" />
              {/* Light beams */}
              <path d="M20 35 L40 30 L40 35 L20 40 Z" fill="#e5e7eb" opacity="0.7" />
              <path d="M80 35 L60 30 L60 35 L80 40 Z" fill="#e5e7eb" opacity="0.7" />
              {/* Waves */}
              <path d="M10 75 Q30 70 50 75 T90 75" stroke="#1e3a8a" strokeWidth="2" fill="none" />
              <path d="M15 80 Q35 75 55 80 T85 80" stroke="#1e3a8a" strokeWidth="2" fill="none" />
            </svg>
          </div>
          <div className="text-2xl font-bold text-blue-900 mb-1">BEACON</div>
          <div className="text-sm font-medium text-gray-600 tracking-wider">SOLUTIONS HUB, LLC</div>
        </div>
      ),
      style: "Clássico, Orientação"
    },
    {
      id: 2,
      name: "Logo Farol Moderno",
      description: "Versão moderna do farol com design mais limpo e contemporâneo",
      component: (
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-900 rounded-full flex items-center justify-center relative">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
              <rect x="10" y="8" width="4" height="12" />
              <rect x="9" y="6" width="6" height="2" />
              <path d="M6 12 L10 10 L10 14 L6 16 Z" opacity="0.5" />
              <path d="M18 12 L14 10 L14 14 L18 16 Z" opacity="0.5" />
              <path d="M4 18 Q12 16 20 18" stroke="white" strokeWidth="1" fill="none" />
            </svg>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-900">BEACON</div>
            <div className="text-sm font-medium text-gray-600">SOLUTIONS HUB</div>
          </div>
        </div>
      ),
      style: "Moderno, Orientação"
    },
    {
      id: 3,
      name: "Logo Farol Minimalista",
      description: "Farol estilizado minimalista, clean e elegante",
      component: (
        <div className="text-center">
          <div className="relative mb-3">
            <svg width="40" height="40" viewBox="0 0 40 40" className="mx-auto">
              <rect x="18" y="12" width="4" height="20" fill="#1e3a8a" />
              <rect x="16" y="10" width="8" height="2" fill="#1e3a8a" />
              <circle cx="20" cy="15" r="2" fill="#fbbf24" opacity="0.8" />
              <path d="M5 30 Q20 28 35 30" stroke="#1e3a8a" strokeWidth="1" fill="none" />
            </svg>
          </div>
          <div className="text-2xl font-light text-blue-900 mb-1">beacon</div>
          <div className="text-xs font-medium text-gray-500 tracking-[0.2em] uppercase">solutions hub</div>
        </div>
      ),
      style: "Minimalista, Elegante"
    },
    {
      id: 4,
      name: "Logo Farol com Ondas Dinâmicas",
      description: "Farol com ondas mais dinâmicas, transmite movimento e progresso",
      component: (
        <div className="text-center">
          <div className="relative mb-3">
            <svg width="70" height="50" viewBox="0 0 100 60" className="mx-auto">
              {/* Dynamic waves */}
              <path d="M0 45 Q25 35 50 45 T100 45" stroke="#3b82f6" strokeWidth="3" fill="none" />
              <path d="M0 50 Q25 40 50 50 T100 50" stroke="#1e3a8a" strokeWidth="2" fill="none" />
              {/* Lighthouse */}
              <rect x="45" y="15" width="10" height="30" fill="#1e3a8a" />
              <rect x="43" y="12" width="14" height="4" fill="#1e3a8a" />
              {/* Light rays */}
              <path d="M25 20 L45 18 L45 25 L25 27 Z" fill="#fbbf24" opacity="0.6" />
              <path d="M75 20 L55 18 L55 25 L75 27 Z" fill="#fbbf24" opacity="0.6" />
            </svg>
          </div>
          <div className="text-2xl font-bold text-blue-900 mb-1">BEACON</div>
          <div className="text-sm font-medium text-gray-600">SOLUTIONS HUB, LLC</div>
        </div>
      ),
      style: "Dinâmico, Movimento"
    },
    {
      id: 5,
      name: "Logo Farol Premium",
      description: "Farol elegante com acabamento premium, ideal para marca de alto padrão",
      component: (
        <div className="text-center">
          <div className="relative mb-3">
            <svg width="50" height="50" viewBox="0 0 60 60" className="mx-auto">
              {/* Premium lighthouse */}
              <rect x="26" y="18" width="8" height="25" fill="#1e3a8a" />
              <rect x="24" y="15" width="12" height="3" fill="#1e3a8a" />
              <circle cx="30" cy="20" r="3" fill="#fbbf24" />
              {/* Premium waves */}
              <path d="M5 45 Q15 40 25 45 Q35 50 45 45 Q50 40 55 45" stroke="#1e3a8a" strokeWidth="2" fill="none" />
              <path d="M10 50 Q20 45 30 50 Q40 55 50 50" stroke="#6b7280" strokeWidth="1" fill="none" />
              {/* Light beams */}
              <path d="M10 25 L26 22 L26 28 L10 31 Z" fill="#fbbf24" opacity="0.4" />
              <path d="M50 25 L34 22 L34 28 L50 31 Z" fill="#fbbf24" opacity="0.4" />
            </svg>
          </div>
          <div className="text-2xl font-bold text-blue-900 mb-1">BEACON</div>
          <div className="text-sm font-medium text-gray-600 tracking-wider">SOLUTIONS HUB</div>
        </div>
      ),
      style: "Premium, Elegante"
    },
    {
      id: 6,
      name: "Logo Farol Corporativo",
      description: "Farol em estilo corporativo sólido, transmite estabilidade e confiança",
      component: (
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 bg-gradient-to-b from-blue-800 to-blue-900 rounded-lg flex items-center justify-center">
            <svg width="28" height="28" viewBox="0 0 40 40" fill="white">
              <rect x="17" y="12" width="6" height="20" />
              <rect x="15" y="10" width="10" height="2" />
              <circle cx="20" cy="15" r="2" fill="#fbbf24" />
              <path d="M5 30 Q20 28 35 30" stroke="white" strokeWidth="1" fill="none" />
              <path d="M8 32 Q20 30 32 32" stroke="white" strokeWidth="1" fill="none" />
            </svg>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-900">BEACON</div>
            <div className="text-sm font-medium text-gray-600">SOLUTIONS HUB, LLC</div>
          </div>
        </div>
      ),
      style: "Corporativo, Sólido"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Opções de Logo - Beacon Solutions Hub
          </h1>
          <p className="text-xl text-gray-600">
            Escolha o design que melhor representa sua marca
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {logoOptions.map((logo) => (
            <Card 
              key={logo.id} 
              className={`cursor-pointer transition-all ${
                selectedLogo === logo.id ? 'ring-2 ring-blue-500 shadow-lg' : 'hover:shadow-md'
              }`}
              onClick={() => setSelectedLogo(logo.id)}
            >
              <CardHeader>
                <div className="h-24 bg-white rounded-lg border flex items-center justify-center mb-4">
                  {logo.component}
                </div>
                <CardTitle className="text-lg">{logo.name}</CardTitle>
                <div className="text-sm text-blue-600 font-medium">{logo.style}</div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{logo.description}</p>
                <Button 
                  className="w-full" 
                  variant={selectedLogo === logo.id ? "default" : "outline"}
                >
                  {selectedLogo === logo.id ? "Selecionado" : "Selecionar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="bg-white rounded-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Logo Selecionado: {logoOptions.find(l => l.id === selectedLogo)?.name}
            </h3>
            <div className="h-32 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center mb-6">
              {logoOptions.find(l => l.id === selectedLogo)?.component}
            </div>
            <p className="text-gray-600 mb-6">
              {logoOptions.find(l => l.id === selectedLogo)?.description}
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg">
                Aplicar Este Logo
              </Button>
              <Button size="lg" variant="outline">
                Voltar ao Site
              </Button>
            </div>
          </div>
        </div>

        {/* Logo em Diferentes Contextos */}
        <div className="mt-16 bg-white rounded-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Como Ficaria em Diferentes Contextos
          </h3>
          <div className="grid md:grid-cols-3 gap-8">
            {/* Header */}
            <div className="text-center">
              <h4 className="font-semibold mb-4">No Header do Site</h4>
              <div className="bg-white border rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="scale-75">
                    {logoOptions.find(l => l.id === selectedLogo)?.component}
                  </div>
                  <div className="text-sm text-gray-500">Menu</div>
                </div>
              </div>
            </div>

            {/* Business Card */}
            <div className="text-center">
              <h4 className="font-semibold mb-4">Em Cartão de Visita</h4>
              <div className="bg-white border rounded-lg p-6 shadow-sm">
                <div className="scale-90 mb-4">
                  {logoOptions.find(l => l.id === selectedLogo)?.component}
                </div>
                <div className="text-xs text-gray-600">
                  <div>Orlando, FL</div>
                  <div>(407) 123-4567</div>
                </div>
              </div>
            </div>

            {/* Vehicle */}
            <div className="text-center">
              <h4 className="font-semibold mb-4">Em Veículo da Empresa</h4>
              <div className="bg-blue-100 border rounded-lg p-6 shadow-sm">
                <div className="scale-110">
                  {logoOptions.find(l => l.id === selectedLogo)?.component}
                </div>
                <div className="text-xs text-blue-800 mt-2">
                  Serviços Residenciais
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
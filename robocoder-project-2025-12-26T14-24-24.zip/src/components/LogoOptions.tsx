"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function LogoOptions() {
  const [selectedLogo, setSelectedLogo] = useState(1);

  const logoOptions = [
    {
      id: 1,
      name: "Logo Moderno - Azul Gradiente",
      description: "Design moderno com gradiente azul, transmite confiança e profissionalismo",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Modern+Blue+Gradient+Logo",
      style: "Moderno, Gradiente"
    },
    {
      id: 2,
      name: "Logo Clássico - Tipografia Elegante",
      description: "Tipografia elegante com ícone de casa, transmite tradição e qualidade",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Classic+Typography+House+Icon",
      style: "Clássico, Elegante"
    },
    {
      id: 3,
      name: "Logo Minimalista - Clean",
      description: "Design limpo e minimalista, foco na simplicidade e clareza",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Minimalist+Clean+Design",
      style: "Minimalista, Clean"
    },
    {
      id: 4,
      name: "Logo Corporativo - Escudo",
      description: "Ícone de escudo transmitindo segurança e proteção",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Corporate+Shield+Security",
      style: "Corporativo, Segurança"
    },
    {
      id: 5,
      name: "Logo Técnico - Ferramentas",
      description: "Ícones de ferramentas integrados, enfatiza expertise técnica",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Technical+Tools+Expert",
      style: "Técnico, Expertise"
    },
    {
      id: 6,
      name: "Logo Premium - Dourado",
      description: "Acabamento dourado premium, transmite luxo e qualidade superior",
      image: "https://placehold.co/300x120?text=BEACON+SOLUTIONS+HUB+Premium+Gold+Luxury",
      style: "Premium, Luxo"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Opções de Logo - Beacon Solutions Hub
          </h1>
          <p className="text-xl text-gray-600">
            Escolha o design que melhor representa sua marca
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {logoOptions.map((logo) => (
            <Card 
              key={logo.id} 
              className={`cursor-pointer transition-all ${
                selectedLogo === logo.id ? 'ring-2 ring-blue-500 shadow-lg' : 'hover:shadow-md'
              }`}
              onClick={() => setSelectedLogo(logo.id)}
            >
              <CardHeader>
                <div className="aspect-[5/2] bg-white rounded-lg border flex items-center justify-center mb-4">
                  <img 
                    src={logo.image} 
                    alt={logo.name}
                    className="max-w-full max-h-full object-contain"
                  />
                </div>
                <CardTitle className="text-lg">{logo.name}</CardTitle>
                <div className="text-sm text-blue-600 font-medium">{logo.style}</div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 mb-4">{logo.description}</p>
                <Button 
                  className="w-full" 
                  variant={selectedLogo === logo.id ? "default" : "outline"}
                >
                  {selectedLogo === logo.id ? "Selecionado" : "Selecionar"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <div className="bg-white rounded-lg p-8 max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Logo Selecionado: {logoOptions.find(l => l.id === selectedLogo)?.name}
            </h3>
            <div className="aspect-[5/2] bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center mb-6">
              <img 
                src={logoOptions.find(l => l.id === selectedLogo)?.image} 
                alt="Logo selecionado"
                className="max-w-full max-h-full object-contain"
              />
            </div>
            <p className="text-gray-600 mb-6">
              {logoOptions.find(l => l.id === selectedLogo)?.description}
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg">
                Aplicar Este Logo
              </Button>
              <Button size="lg" variant="outline">
                Solicitar Customização
              </Button>
            </div>
          </div>
        </div>

        {/* Logo Guidelines */}
        <div className="mt-16 bg-white rounded-lg p-8">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">
            Diretrizes de Logo
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Características Importantes:</h4>
              <ul className="space-y-2 text-gray-600">
                <li>• <strong>Legibilidade:</strong> Texto claro em todos os tamanhos</li>
                <li>• <strong>Versatilidade:</strong> Funciona em fundos claros e escuros</li>
                <li>• <strong>Escalabilidade:</strong> Mantém qualidade em diferentes tamanhos</li>
                <li>• <strong>Profissionalismo:</strong> Transmite confiança e competência</li>
                <li>• <strong>Memorabilidade:</strong> Fácil de lembrar e reconhecer</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Aplicações do Logo:</h4>
              <ul className="space-y-2 text-gray-600">
                <li>• Website e materiais digitais</li>
                <li>• Cartões de visita e papelaria</li>
                <li>• Uniformes e veículos da empresa</li>
                <li>• Materiais de marketing e publicidade</li>
                <li>• Redes sociais e aplicativos</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
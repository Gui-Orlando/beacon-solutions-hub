# 🚀 DEPLOY PASSO A PASSO - beaconsolutionshub.com

## ✅ SEUS DADOS ATUALIZADOS NO SITE:
- **Domínio:** beaconsolutionshub.com
- **WhatsApp:** (689) 297-0260
- **Email:** info@beaconsolutionshub.com
- **Plataforma:** Website Hosting Essentials

---

## 📋 PASSO A PASSO COMPLETO:

### **ETAPA 1: PREPARAR CÓDIGO NO GITHUB**

1. **Criar Repositório no GitHub:**
   - Acesse [github.com](https://github.com)
   - Clique "New repository"
   - Nome: `beacon-solutions-hub`
   - Público ou Privado (sua escolha)
   - Clique "Create repository"

2. **Fazer Upload dos Arquivos:**
   - Baixe todos os arquivos do sandbox atual
   - Faça upload para o repositório GitHub
   - Ou use GitHub Desktop/Git CLI

### **ETAPA 2: CONECTAR VERCEL AO GITHUB**

1. **No Vercel Dashboard:**
   - Acesse [vercel.com/dashboard](https://vercel.com/dashboard)
   - Clique "New Project"
   - Selecione "Import Git Repository"
   - Escolha seu repositório `beacon-solutions-hub`

2. **Configurações de Deploy:**
   - **Framework Preset:** Next.js (detectado automaticamente)
   - **Root Directory:** `./` (padrão)
   - **Build Command:** `pnpm run build` (padrão)
   - **Output Directory:** `.next` (padrão)
   - Clique "Deploy"

### **ETAPA 3: CONFIGURAR SEU DOMÍNIO**

1. **Adicionar Domínio no Vercel:**
   - No seu projeto → Settings → Domains
   - Clique "Add Domain"
   - Digite: `beaconsolutionshub.com`
   - Clique "Add"

2. **Configurar DNS (Website Hosting Essentials):**
   
   **No painel da Website Hosting Essentials:**
   
   **A) Para domínio principal (beaconsolutionshub.com):**
   ```
   Tipo: A
   Nome: @
   Valor: 76.76.19.61
   TTL: 3600
   ```
   
   **B) Para www (www.beaconsolutionshub.com):**
   ```
   Tipo: CNAME
   Nome: www
   Valor: cname.vercel-dns.com
   TTL: 3600
   ```
   
   **C) Verificação (se solicitado):**
   ```
   Tipo: TXT
   Nome: _vercel
   Valor: [Vercel fornecerá este valor]
   TTL: 3600
   ```

### **ETAPA 4: AGUARDAR PROPAGAÇÃO**
- **Tempo:** 5-30 minutos
- **Verificar:** Digite seu domínio no navegador
- **Status:** Vercel mostrará "Domain configured correctly"

---

## 🔧 **CONFIGURAÇÕES AVANÇADAS:**

### **Redirecionamentos:**
No Vercel → Settings → Redirects:
```
Source: www.beaconsolutionshub.com/*
Destination: https://beaconsolutionshub.com/:splat
Permanent: true
```

### **Headers de Segurança:**
No Vercel → Settings → Headers:
```json
{
  "source": "/(.*)",
  "headers": [
    {
      "key": "X-Frame-Options",
      "value": "DENY"
    },
    {
      "key": "X-Content-Type-Options", 
      "value": "nosniff"
    }
  ]
}
```

---

## 📱 **TESTE FINAL:**

Após o deploy, teste:
- ✅ **beaconsolutionshub.com** carrega o site
- ✅ **WhatsApp** abre com número (689) 297-0260
- ✅ **Email** mostra info@beaconsolutionshub.com
- ✅ **Todas as páginas** funcionando
- ✅ **SSL** ativo (https://)

---

## 🆘 **PROBLEMAS COMUNS:**

### **DNS não propaga:**
- Aguarde até 24h
- Use [whatsmydns.net](https://whatsmydns.net) para verificar

### **Erro 404:**
- Verifique se o repositório está público
- Confirme se o build passou no Vercel

### **SSL não ativa:**
- Aguarde alguns minutos
- Vercel ativa SSL automaticamente

---

## 📞 **SUPORTE:**

Se precisar de ajuda:
1. **Screenshots** do painel DNS
2. **Mensagens de erro** do Vercel
3. **Status** da propagação DNS

**Posso te ajudar com cada etapa! 🚀**